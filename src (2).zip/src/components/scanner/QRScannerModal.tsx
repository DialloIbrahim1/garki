
"use client";

import React, { useState, useEffect, useRef } from 'react';
import { X, Check, AlertTriangle, Users as UsersIcon, LogIn, LogOut, Scan, Sparkles, Smartphone, Play, History, Circle, Power } from 'lucide-react';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Student } from '../SchoolGuardApp';
import { personalizeParentCommunication } from '@/ai/flows/personalized-parent-communication';
import { Language, translations } from '@/lib/translations';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { Alert, AlertTitle, AlertDescription } from '@/components/ui/alert';

interface QRScannerModalProps {
  isOpen: boolean;
  onClose: () => void;
  students: Student[];
  language: Language;
  onScan: (id: string, status: 'present' | 'absent') => void;
}

interface ScanRecord {
  student: Student;
  status: 'entry' | 'exit';
  time: string;
}

export function QRScannerModal({ isOpen, onClose, students, language, onScan }: QRScannerModalProps) {
  const [scanResult, setScanResult] = useState<{ student: Student, status: 'entry' | 'exit', messageSent?: boolean } | null>(null);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [hasCameraPermission, setHasCameraPermission] = useState<boolean | null>(null);
  const [isNotifying, setIsNotifying] = useState(false);
  const [isCameraActive, setIsCameraActive] = useState(false);
  const [sessionHistory, setSessionHistory] = useState<ScanRecord[]>([]);
  const videoRef = useRef<HTMLVideoElement>(null);
  const { toast } = useToast();
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  useEffect(() => {
    if (!isOpen) {
      stopCamera();
    }
  }, [isOpen]);

  const startCamera = async () => {
    setCameraError(null);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ 
        video: { facingMode: 'environment', width: { ideal: 1280 }, height: { ideal: 720 } } 
      });
      setHasCameraPermission(true);
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
        setIsCameraActive(true);
      }
    } catch (err: any) {
      setHasCameraPermission(false);
      setCameraError(err.name === 'NotAllowedError' ? "Accès caméra refusé" : "Erreur d'initialisation caméra");
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(track => track.stop());
      videoRef.current.srcObject = null;
    }
    setIsCameraActive(false);
  };

  const playSuccessSound = () => {
    try {
      if (typeof navigator !== 'undefined' && navigator.vibrate) {
        navigator.vibrate(100);
      }
      const AudioContextClass = (window.AudioContext || (window as any).webkitAudioContext);
      const audioCtx = new AudioContextClass();
      const playTone = (freq: number, start: number, duration: number) => {
        const osc = audioCtx.createOscillator();
        const gain = audioCtx.createGain();
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.type = 'sine';
        osc.frequency.setValueAtTime(freq, audioCtx.currentTime + start);
        gain.gain.setValueAtTime(0, audioCtx.currentTime + start + 0.01);
        gain.gain.linearRampToValueAtTime(0.1, audioCtx.currentTime + start + 0.01);
        gain.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + start + duration);
        osc.start(audioCtx.currentTime + start);
        osc.stop(audioCtx.currentTime + start + duration);
      };
      playTone(523.25, 0, 0.15);
      playTone(783.99, 0.1, 0.2);
    } catch (e) {}
  };

  const simulateScan = async (student: Student, type: 'entry' | 'exit') => {
    if (!isCameraActive) {
      toast({ variant: "destructive", title: "Scanner Inactif", description: "Veuillez d'abord cliquer sur 'Commencer le scan'." });
      return;
    }
    playSuccessSound();
    onScan(student.id, 'present');
    const scanTime = new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    setScanResult({ student, status: type, messageSent: false });
    setIsNotifying(true);
    setSessionHistory(prev => [{ student, status: type, time: scanTime }, ...prev].slice(0, 5));
    try {
      const { message } = await personalizeParentCommunication({
        studentName: student.name,
        studentClass: student.class,
        messageType: type,
        scanTime: scanTime
      });
      setScanResult(prev => prev ? { ...prev, messageSent: true } : null);
    } catch (err) {} finally {
      setIsNotifying(false);
      setTimeout(() => setScanResult(null), 3000);
    }
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-md p-0 overflow-hidden border-none rounded-[2.5rem] bg-background shadow-2xl" dir={isRtl ? 'rtl' : 'ltr'}>
        <div className="relative flex flex-col items-center">
          <div className={cn("w-full p-5 flex justify-between items-center border-b border-border bg-white z-10", isRtl ? "flex-row-reverse" : "")}>
            <div className={cn("flex items-center gap-3", isRtl ? "flex-row-reverse text-right" : "")}>
              <div className="w-10 h-10 bg-primary/10 rounded-xl flex items-center justify-center text-primary shadow-sm border border-primary/5">
                <Scan size={20} />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <h2 className="text-base font-black uppercase italic tracking-tight leading-none">{t.modals.scanTitle}</h2>
                  {isCameraActive && (
                    <div className="flex items-center gap-1.5 bg-emerald-50 px-2 py-0.5 rounded-full border border-emerald-100">
                      <Circle size={6} className="fill-emerald-500 text-emerald-500 animate-pulse" />
                      <span className="text-[7px] font-black text-emerald-600 uppercase tracking-widest">LIVE</span>
                    </div>
                  )}
                </div>
                <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-widest mt-1">{t.modals.scanSubtitle}</p>
              </div>
            </div>
            <button onClick={onClose} className="p-2.5 bg-muted rounded-xl hover:bg-muted-foreground/10 transition-all active:scale-90"><X size={18}/></button>
          </div>

          <div className="w-full aspect-[16/10] relative bg-slate-950 flex items-center justify-center overflow-hidden">
            {/* Always keep video tag to prevent race conditions */}
            <video 
              ref={videoRef} 
              autoPlay 
              playsInline 
              muted
              className={cn("w-full h-full object-cover", isCameraActive ? "opacity-90" : "hidden")} 
            />

            {!isCameraActive && (
              <div className="flex flex-col items-center gap-6 p-10 text-center animate-in fade-in duration-500">
                <div className="w-24 h-24 rounded-[2rem] bg-white/5 border border-white/10 flex items-center justify-center text-white/20 relative">
                  <Scan size={48} className="opacity-50" />
                  <div className="absolute inset-0 border-4 border-primary/20 rounded-[2rem] scale-110 animate-pulse" />
                </div>
                <div className="space-y-2">
                  <p className="text-[10px] font-black text-white/40 uppercase tracking-[0.2em]">{language === 'fr' ? 'CAMERA EN ATTENTE' : 'CAMERA WAITING'}</p>
                  {hasCameraPermission === false && (
                    <Alert variant="destructive" className="mt-2 bg-rose-500/10 border-rose-500/20 text-rose-400">
                      <AlertTitle className="text-[10px] font-black uppercase tracking-widest">Accès Refusé</AlertTitle>
                      <AlertDescription className="text-[8px] font-bold">Veuillez autoriser l'accès à la caméra dans vos réglages.</AlertDescription>
                    </Alert>
                  )}
                </div>
              </div>
            )}

            {isCameraActive && !scanResult && (
              <div className="absolute inset-0 flex items-center justify-center p-6 pointer-events-none">
                <div className="w-full h-full border-2 border-white/20 rounded-[1.5rem] relative overflow-hidden">
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-4 border-l-4 border-primary rounded-tl-lg" />
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-4 border-r-4 border-primary rounded-tr-lg" />
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-4 border-l-4 border-primary rounded-bl-lg" />
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-4 border-r-4 border-primary rounded-br-lg" />
                  <div className="absolute left-0 w-full h-1 bg-gradient-to-r from-transparent via-primary to-transparent shadow-[0_0_20px_rgba(70,70,219,1)] animate-scan" />
                </div>
              </div>
            )}

            {scanResult && (
              <div className={cn("absolute inset-0 flex flex-col items-center justify-center p-6 text-white text-center animate-in fade-in zoom-in duration-500 z-20 backdrop-blur-md", scanResult.status === 'entry' ? 'bg-emerald-600/90' : 'bg-primary/90')}>
                <div className="w-20 h-20 bg-white rounded-[1.2rem] p-1 mb-3 shadow-2xl relative rotate-3">
                  {scanResult.student.photo ? (
                    <img src={scanResult.student.photo} className="w-full h-full object-cover rounded-[1rem]" />
                  ) : (
                    <div className="w-full h-full bg-muted flex items-center justify-center text-muted-foreground/30 rounded-[1rem]">
                      <UsersIcon size={28}/>
                    </div>
                  )}
                  <div className={cn("absolute -bottom-1 -right-1 w-8 h-8 rounded-lg flex items-center justify-center border-2 border-white shadow-2xl", scanResult.status === 'entry' ? 'bg-emerald-500' : 'bg-primary')}>
                    {scanResult.status === 'entry' ? <LogIn size={16} /> : <LogOut size={16} />}
                  </div>
                </div>
                <h3 className="text-lg font-black uppercase tracking-tighter mb-1">{scanResult.student.name}</h3>
                <div className="mt-4 w-full max-w-[180px] bg-black/40 backdrop-blur-xl rounded-[0.8rem] p-2.5 flex flex-col items-center gap-1.5 border border-white/10">
                  {isNotifying ? (
                    <div className="flex items-center gap-1.5">
                      <Sparkles size={12} className="text-white animate-pulse" />
                      <span className="text-[7px] font-black uppercase tracking-widest">Notification...</span>
                    </div>
                  ) : scanResult.messageSent ? (
                    <div className="flex items-center gap-1.5 text-emerald-300">
                      <Smartphone size={12} />
                      <span className="text-[7px] font-black uppercase tracking-widest">Parent Notifié</span>
                      <Check size={10} />
                    </div>
                  ) : (
                    <span className="text-[7px] font-black uppercase tracking-widest opacity-40">Traitement</span>
                  )}
                </div>
              </div>
            )}
          </div>

          <div className="w-full p-5 bg-white space-y-5">
            <div className="space-y-3">
              <div className={cn("flex items-center justify-between", isRtl ? "flex-row-reverse" : "")}>
                <p className="text-[8px] font-black text-muted-foreground uppercase tracking-[0.2em]">{t.modals.simulation}</p>
                <div className="h-px flex-1 bg-border mx-3" />
              </div>
              <div className="grid grid-cols-1 gap-2 max-h-[100px] overflow-y-auto no-scrollbar">
                {students.slice(0, 3).map(s => (
                  <div key={s.id} className={cn("flex items-center justify-between p-2 bg-muted/20 hover:bg-muted/40 rounded-xl border border-border/40 transition-all", isRtl ? "flex-row-reverse" : "")}>
                    <div className={cn("flex items-center gap-2", isRtl ? "flex-row-reverse text-right" : "")}>
                      <div className="w-7 h-7 rounded-lg bg-white border border-border overflow-hidden">
                        {s.photo ? <img src={s.photo} className="w-full h-full object-cover" /> : <UsersIcon size={12} className="m-auto text-muted-foreground/30 mt-1.5" />}
                      </div>
                      <p className="text-[8px] font-black uppercase truncate max-w-[100px]">{s.name}</p>
                    </div>
                    <div className={cn("flex gap-1", isRtl ? "flex-row-reverse" : "")}>
                      <button onClick={() => simulateScan(s, 'entry')} disabled={!!scanResult || !isCameraActive} className="p-2 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 disabled:opacity-30"><LogIn size={10} /></button>
                      <button onClick={() => simulateScan(s, 'exit')} disabled={!!scanResult || !isCameraActive} className="p-2 bg-primary text-white rounded-lg hover:bg-primary/90 disabled:opacity-30"><LogOut size={10} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="flex flex-col gap-2 pt-4 border-t border-border">
              {!isCameraActive ? (
                <button onClick={startCamera} className="w-full bg-primary text-white py-3.5 rounded-[1.25rem] font-black uppercase text-[9px] tracking-[0.2em] shadow-xl shadow-primary/20 flex items-center justify-center gap-2">
                  <Play size={12} fill="white" /> {t.modals.startScan}
                </button>
              ) : (
                <button onClick={stopCamera} className="w-full bg-amber-500 text-white py-3.5 rounded-[1.25rem] font-black uppercase text-[9px] tracking-[0.2em] shadow-xl shadow-amber-500/20 flex items-center justify-center gap-2">
                  <Power size={12} /> ARRÊTER LE SCAN
                </button>
              )}
              <button onClick={onClose} className="w-full py-3.5 bg-foreground text-background rounded-[1.25rem] font-black uppercase text-[9px] tracking-[0.2em] hover:bg-black flex items-center justify-center gap-2">
                <Check size={12} /> {t.modals.finish}
              </button>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}
