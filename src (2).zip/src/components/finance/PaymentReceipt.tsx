"use client";

import React from 'react';
import { Printer, CheckCircle2, Calendar, User, Banknote, Share2, Smartphone } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';
import { formatCurrency } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';

interface PaymentReceiptProps {
  student: Student;
  amountGnf: number;
  date: Date;
  transactionId: string;
  currency: string;
  language: Language;
  onClose: () => void;
}

export function PaymentReceipt({ student, amountGnf, date, transactionId, currency, language, onClose }: PaymentReceiptProps) {
  const t = translations[language];
  const { toast } = useToast();
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  const receiptContent = `${t.financeList.receipt}\n\n${t.attendanceList.student}: ${student.name} (${student.class})\n${t.financeList.transactionId}: ${transactionId}\n${t.financeList.paymentDate}: ${date.toLocaleString()}\n${t.financeList.amountReceived}: ${formatCurrency(amountGnf, currency)}`;

  const shareWhatsApp = () => {
    const phone = student.phoneWhatsapp?.replace(/\s/g, '');
    if (!phone) {
      toast({ variant: "destructive", title: "Erreur", description: "Numéro WhatsApp manquant." });
      return;
    }
    const url = `https://wa.me/${phone}?text=${encodeURIComponent(receiptContent)}`;
    window.open(url, '_blank');
  };

  const shareSMS = () => {
    const phone = student.phoneSms?.replace(/\s/g, '');
    if (!phone) {
      toast({ variant: "destructive", title: "Erreur", description: "Numéro SMS manquant." });
      return;
    }
    const url = `sms:${phone}?body=${encodeURIComponent(receiptContent)}`;
    window.location.href = url;
  };

  return (
    <div className="relative flex flex-col items-center gap-6 animate-in zoom-in duration-300 max-w-full">
      <div id="payment-receipt" className={`w-[95vw] sm:w-[550px] bg-white rounded-[2.5rem] relative overflow-hidden shadow-2xl p-6 sm:p-10 border border-border print:m-0 print:border-none print:shadow-none ${isRtl ? 'text-right' : ''}`}>
        {/* Header */}
        <div className={`flex justify-between items-start mb-8 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <div className="w-10 h-10 bg-primary rounded-[1rem] flex items-center justify-center text-white italic font-black text-lg rotate-3 shadow-lg shadow-primary/20">
              G
            </div>
            <div>
              <h3 className="text-primary text-[10px] font-black uppercase tracking-widest italic leading-tight">{t.title}</h3>
              <p className="text-[7px] font-bold text-muted-foreground uppercase tracking-widest">{t.subtitle}</p>
            </div>
          </div>
          <div className={`text-emerald-500 flex flex-col items-center ${isRtl ? 'text-left' : 'text-right'}`}>
            <CheckCircle2 size={24} />
            <p className="text-[8px] font-black uppercase mt-1 tracking-widest">{language === 'fr' ? 'PAIEMENT RÉUSSI' : 'PAYMENT SUCCESS'}</p>
          </div>
        </div>

        {/* Receipt Body */}
        <div className="space-y-6">
          <div className="text-center pb-6 border-b border-dashed border-border">
            <h2 className="text-xl font-black text-foreground uppercase tracking-tighter">{t.financeList.receipt}</h2>
            <p className="text-[9px] font-bold text-muted-foreground uppercase tracking-[0.2em] mt-1">{t.financeList.transactionId}: {transactionId}</p>
          </div>

          <div className="grid grid-cols-1 gap-4">
            <ReceiptRow icon={<User size={14}/>} label={t.attendanceList.student} value={student.name} subValue={student.class} isRtl={isRtl} />
            <ReceiptRow icon={<Calendar size={14}/>} label={t.financeList.paymentDate} value={date.toLocaleDateString()} subValue={date.toLocaleTimeString()} isRtl={isRtl} />
            
            <div className={`p-5 bg-primary/5 rounded-[1.5rem] border border-primary/10 flex justify-between items-center ${isRtl ? 'flex-row-reverse' : ''}`}>
               <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                 <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white">
                   <Banknote size={16} />
                 </div>
                 <p className="text-[10px] font-black text-primary uppercase tracking-widest">{t.financeList.amountReceived}</p>
               </div>
               <p className="text-xl font-black text-primary">{formatCurrency(amountGnf, currency)}</p>
            </div>
          </div>
        </div>

        {/* Print Disclaimer */}
        <div className="mt-8 pt-6 border-t border-border flex justify-between items-center opacity-40 italic">
          <p className="text-[7px] font-bold uppercase tracking-widest">© {new Date().getFullYear()} GARKI IB APP</p>
          <p className="text-[7px] font-bold uppercase tracking-widest">PRO BY IBRAHIMA GARKI DIALLO</p>
        </div>
      </div>

      {/* Actions */}
      <div className={`grid grid-cols-2 sm:grid-cols-4 gap-3 w-full sm:w-[550px] no-print ${isRtl ? 'rtl' : 'ltr'}`}>
        <button 
          onClick={onClose} 
          className="col-span-1 px-4 py-4 bg-white/10 text-white hover:bg-white/20 rounded-2xl font-black uppercase text-[9px] transition-all"
        >
          {t.modals.cancel}
        </button>
        <button 
          onClick={() => window.print()} 
          className="col-span-1 px-4 py-4 bg-primary text-white hover:bg-primary/90 rounded-2xl font-black uppercase text-[9px] flex items-center justify-center gap-2 shadow-xl shadow-primary/20 transition-all"
        >
          <Printer size={16} /> {t.financeList.printReceipt}
        </button>
        <button 
          onClick={shareWhatsApp} 
          className="col-span-1 px-4 py-4 bg-emerald-500 text-white hover:bg-emerald-600 rounded-2xl font-black uppercase text-[9px] flex items-center justify-center gap-2 shadow-xl shadow-emerald-500/20 transition-all"
        >
          <Share2 size={16} /> {t.financeList.sendWhatsApp}
        </button>
        <button 
          onClick={shareSMS} 
          className="col-span-1 px-4 py-4 bg-sky-500 text-white hover:bg-sky-600 rounded-2xl font-black uppercase text-[9px] flex items-center justify-center gap-2 shadow-xl shadow-sky-500/20 transition-all"
        >
          <Smartphone size={16} /> {t.financeList.sendSMS}
        </button>
      </div>
    </div>
  );
}

function ReceiptRow({ icon, label, value, subValue, isRtl }: any) {
  return (
    <div className={`flex justify-between items-center ${isRtl ? 'flex-row-reverse' : ''}`}>
      <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
        <div className="text-muted-foreground/30">{icon}</div>
        <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{label}</p>
      </div>
      <div className={isRtl ? 'text-left' : 'text-right'}>
        <p className="text-xs font-black text-foreground uppercase tracking-tight leading-none">{value}</p>
        {subValue && <p className="text-[8px] font-bold text-primary uppercase mt-1">{subValue}</p>}
      </div>
    </div>
  );
}
