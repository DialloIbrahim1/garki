"use client";

import React, { useState, useMemo } from 'react';
import { Wallet, Send, Banknote, Check, AlertCircle, History, Globe } from 'lucide-react';
import { Student, Transaction, PaymentSummary } from '../SchoolGuardApp';
import { CURRENCIES, FRAIS_SCOLARITE_BASE } from '@/lib/constants';
import { personalizeParentCommunication } from '@/ai/flows/personalized-parent-communication';
import { useToast } from '@/hooks/use-toast';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Card, CardHeader, CardTitle, CardContent } from '@/components/ui/card';
import { formatCurrency } from '@/lib/utils';
import { Language, translations } from '@/lib/translations';
import { PaymentReceipt } from './PaymentReceipt';

interface FinanceManagementProps {
  students: Student[];
  transactions: Transaction[];
  payments: Record<string, PaymentSummary>;
  currency: string;
  language: Language;
  setCurrency: (c: string) => void;
  onPay: (id: string, amountGnf: number) => void;
}

export function FinanceManagement({ students, transactions, payments, currency, language, setCurrency, onPay }: FinanceManagementProps) {
  const { toast } = useToast();
  const [reminding, setReminding] = useState<string | null>(null);
  const [selectedStudentForPayment, setSelectedStudentForPayment] = useState<Student | null>(null);
  const [lastPayment, setLastPayment] = useState<{ student: Student, amountGnf: number, date: Date, transactionId: string } | null>(null);
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  const recentTransactions = useMemo(() => {
    return [...transactions].slice(0, 10);
  }, [transactions]);

  const handleRemind = async (student: Student) => {
    const amountPaid = payments[student.id]?.amountPaid || 0;
    const remaining = FRAIS_SCOLARITE_BASE - amountPaid;
    if (remaining <= 0) return;

    setReminding(student.id);
    try {
      const { message } = await personalizeParentCommunication({
        studentName: student.name,
        studentClass: student.class,
        messageType: 'finance',
        remainingAmount: formatCurrency(remaining, currency)
      });

      const encodedMsg = encodeURIComponent(message);
      const phone = student.phoneWhatsapp || student.phoneSms;
      if (phone) {
        window.open(`https://wa.me/${phone.replace(/\s/g, '')}?text=${encodedMsg}`, '_blank');
      }
      toast({ title: t.financeList.remind });
    } catch (err) {
      toast({ variant: "destructive", title: "Erreur" });
    } finally {
      setReminding(null);
    }
  };

  const currentRate = CURRENCIES.find(c => c.code === currency)?.rate || 1;

  const handleProcessPayment = () => {
    const input = document.getElementById('payAmount') as HTMLInputElement;
    const amtInCurrency = parseFloat(input.value);
    if (amtInCurrency > 0 && selectedStudentForPayment) {
      const amtInGnf = Math.round(amtInCurrency / currentRate);
      const transactionId = `TXN-${Math.random().toString(36).substr(2, 9).toUpperCase()}`;
      onPay(selectedStudentForPayment.id, amtInGnf);
      
      // Store details for receipt modal
      setLastPayment({
        student: selectedStudentForPayment,
        amountGnf: amtInGnf,
        date: new Date(),
        transactionId
      });
      
      setSelectedStudentForPayment(null);
    }
  };

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Currency Selector */}
      <div className={`bg-white p-6 rounded-[2.5rem] border border-border shadow-sm flex flex-col md:flex-row items-center gap-6 ${isRtl ? 'md:flex-row-reverse text-right' : ''}`}>
        <div className={`flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className="w-12 h-12 bg-primary/10 rounded-2xl flex items-center justify-center text-primary">
            <Globe size={24} />
          </div>
          <div>
            <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{t.financeList.config}</p>
            <h3 className="text-lg font-black text-foreground uppercase">{t.financeList.autoConversion}</h3>
          </div>
        </div>
        
        <div className={`flex-1 flex flex-wrap gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
          {CURRENCIES.map(c => (
            <button 
              key={c.code}
              onClick={() => setCurrency(c.code)}
              className={`px-4 py-2 rounded-xl text-[10px] font-black uppercase transition-all ${currency === c.code ? 'bg-primary text-white shadow-lg' : 'bg-muted text-muted-foreground hover:bg-muted-foreground/10'}`}
              title={`${c.label} - ${c.region}`}
            >
              {c.code}
            </button>
          ))}
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <div className="lg:col-span-2 bg-white rounded-[3rem] border border-border shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-muted/50 border-b border-border">
                <tr className={isRtl ? 'text-right' : ''}>
                  <th className="px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest">{t.attendanceList.student}</th>
                  <th className="px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest text-center">{t.financeList.paidTuition}</th>
                  <th className="px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest text-center">{t.financeList.remainingBalance}</th>
                  <th className={`px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest ${isRtl ? 'text-left' : 'text-right'}`}>{t.financeList.actions}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-border">
                {students.map(s => {
                  const amountPaidGnf = payments[s.id]?.amountPaid || 0;
                  const remainingGnf = FRAIS_SCOLARITE_BASE - amountPaidGnf;
                  const isFull = remainingGnf <= 0;
                  const progress = (amountPaidGnf / FRAIS_SCOLARITE_BASE) * 100;

                  return (
                    <tr key={s.id} className="hover:bg-muted/30 transition-colors">
                      <td className={`px-10 py-6 ${isRtl ? 'text-right' : ''}`}>
                        <div>
                          <p className="text-sm font-black text-foreground tracking-tight uppercase">{s.name}</p>
                          <p className="text-[10px] font-bold text-primary uppercase mt-0.5">{s.class}</p>
                        </div>
                      </td>
                      <td className="px-10 py-6">
                        <div className="flex flex-col items-center gap-2">
                          <span className="text-xs font-black text-foreground">{formatCurrency(amountPaidGnf, currency)}</span>
                          <div className="w-32 h-1.5 bg-muted rounded-full overflow-hidden">
                            <div className="h-full bg-primary transition-all duration-1000" style={{ width: `${progress}%` }} />
                          </div>
                        </div>
                      </td>
                      <td className="px-10 py-6 text-center">
                        <span className={`text-xs font-black ${isFull ? 'text-emerald-500' : 'text-rose-500'}`}>
                          {formatCurrency(remainingGnf, currency)}
                        </span>
                      </td>
                      <td className="px-10 py-6">
                        <div className={`flex gap-3 ${isRtl ? 'justify-start' : 'justify-end'}`}>
                          {!isFull && (
                            <button 
                              onClick={() => handleRemind(s)} 
                              disabled={reminding === s.id}
                              className={`px-4 py-2.5 bg-amber-50 text-amber-600 rounded-xl text-[9px] font-black uppercase tracking-widest hover:bg-amber-100 transition-colors flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}
                            >
                              <Send size={14} /> {t.financeList.remind}
                            </button>
                          )}
                          <button 
                            onClick={() => setSelectedStudentForPayment(s)}
                            disabled={isFull}
                            className={`px-5 py-2.5 rounded-xl text-[9px] font-black uppercase tracking-widest transition-all ${isFull ? 'bg-emerald-50 text-emerald-500' : 'bg-primary text-white hover:bg-primary/90 shadow-lg shadow-primary/20'}`}
                          >
                            {isFull ? <Check size={14}/> : t.financeList.collect}
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        <Card className="rounded-[3rem] border-none shadow-xl bg-white overflow-hidden self-start">
          <CardHeader className="bg-primary/5">
            <CardTitle className={`text-xs font-black flex items-center gap-2 text-foreground uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}>
              <History className={`h-4 w-4 text-primary ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.financeList.history}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            <div className="space-y-6">
              {recentTransactions.length > 0 ? recentTransactions.map((tx, idx) => {
                const student = students.find(s => s.id === tx.studentId);
                return (
                  <div key={idx} className={`flex justify-between items-center border-b border-border pb-4 last:border-0 last:pb-0 ${isRtl ? 'flex-row-reverse text-right' : ''}`}>
                    <div className="flex-1">
                      <p className="text-[10px] font-black uppercase text-foreground leading-tight truncate max-w-[120px]">{student?.name || 'Inconnu'}</p>
                      <p className="text-[8px] font-bold text-muted-foreground uppercase mt-0.5">
                        {new Date(tx.date).toLocaleDateString()} • {tx.id}
                      </p>
                    </div>
                    <div className={isRtl ? 'text-left' : 'text-right'}>
                      <p className="text-[10px] font-black text-emerald-600">+{formatCurrency(tx.amountGnf, currency)}</p>
                    </div>
                  </div>
                );
              }) : (
                <div className="text-center py-10">
                  <AlertCircle className="mx-auto h-8 w-8 text-muted-foreground/20 mb-2" />
                  <p className="text-[10px] font-bold text-muted-foreground uppercase">{t.financeList.noTransaction}</p>
                </div>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Payment Dialog */}
      <Dialog open={!!selectedStudentForPayment} onOpenChange={() => setSelectedStudentForPayment(null)}>
        <DialogContent className="rounded-[3rem] p-0 overflow-hidden border-none max-w-md" dir={isRtl ? 'rtl' : 'ltr'}>
          <div className={`bg-primary p-8 text-white ${isRtl ? 'text-right' : ''}`}>
            <DialogTitle className="text-xl font-black uppercase italic tracking-tight">{t.modals.paymentTitle}</DialogTitle>
            <p className="text-sm font-bold opacity-80 mt-1 uppercase tracking-wider">{selectedStudentForPayment?.name}</p>
          </div>
          <div className="p-8 space-y-6 bg-white">
            <div className={`space-y-2 ${isRtl ? 'text-right' : ''}`}>
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">
                {language === 'fr' ? `Montant saisi en ${currency}` : `Amount in ${currency}`}
              </label>
              <div className="relative">
                <Banknote className={`absolute ${isRtl ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-muted-foreground/30`} size={20} />
                <input 
                  type="number" 
                  id="payAmount"
                  className={`w-full ${isRtl ? 'pr-14 pl-6 text-right' : 'pl-14 pr-6'} py-5 bg-muted/30 border-none rounded-3xl outline-none font-black text-2xl focus:ring-2 focus:ring-primary text-foreground`}
                  placeholder="0"
                  autoFocus
                />
              </div>
              <p className="text-[8px] font-bold text-muted-foreground uppercase tracking-widest px-1">
                {language === 'fr' ? `Conversion automatique au taux de ${currentRate.toFixed(4)}` : `Auto-conversion at rate ${currentRate.toFixed(4)}`}
              </p>
            </div>
            <div className={`flex gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <button onClick={() => setSelectedStudentForPayment(null)} className="flex-1 py-4 bg-muted text-muted-foreground rounded-2xl font-black uppercase text-[10px]">{t.modals.cancel}</button>
              <button 
                onClick={handleProcessPayment}
                className="flex-[2] py-4 bg-primary text-white rounded-2xl font-black uppercase text-[10px] shadow-xl shadow-primary/20 hover:bg-primary/90"
              >
                {t.modals.confirm}
              </button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Receipt Modal */}
      {lastPayment && (
        <Dialog open={!!lastPayment} onOpenChange={() => setLastPayment(null)}>
          <DialogContent className="max-w-fit p-0 bg-transparent border-none shadow-none no-scrollbar overflow-y-auto max-h-[90vh]">
            <PaymentReceipt 
              student={lastPayment.student}
              amountGnf={lastPayment.amountGnf}
              date={lastPayment.date}
              transactionId={lastPayment.transactionId}
              currency={currency}
              language={language}
              onClose={() => setLastPayment(null)}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
