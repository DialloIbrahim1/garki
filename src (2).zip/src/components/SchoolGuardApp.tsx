
"use client";

import React, { useState, useMemo, useCallback } from 'react';
import { 
  Users, UserPlus, ScanLine, Wallet, LayoutDashboard, 
  UserCheck, ShieldCheck, Languages, Mail, Phone, LogOut, FileText, ClipboardList
} from 'lucide-react';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { StudentManagement } from './students/StudentManagement';
import { AttendanceTracking } from './attendance/AttendanceTracking';
import { FinanceManagement } from './finance/FinanceManagement';
import { CertificateManagement } from './certificates/CertificateManagement';
import { ReportManagement } from './reports/ReportManagement';
import { DashboardOverview } from './dashboard/DashboardOverview';
import { QRScannerModal } from './scanner/QRScannerModal';
import { StudentFormModal } from './students/StudentFormModal';
import { useToast } from "@/hooks/use-toast";
import { FRAIS_SCOLARITE_BASE, DEVISE_DEFAULT } from '@/lib/constants';
import { translations, Language } from '@/lib/translations';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { 
  useFirestore, 
  useAuth, 
  useCollection, 
  useDoc 
} from '@/firebase';
import { 
  collection, 
  doc, 
  setDoc, 
  addDoc, 
  deleteDoc, 
  query, 
  orderBy, 
  serverTimestamp 
} from 'firebase/firestore';
import { errorEmitter } from '@/firebase/error-emitter';
import { FirestorePermissionError } from '@/firebase/errors';
import { signOut } from 'firebase/auth';

export interface Student {
  id: string;
  name: string;
  class: string;
  bloodGroup: string;
  phoneSms: string;
  phoneWhatsapp: string;
  photo?: string;
  createdAt?: any;
}

export interface Transaction {
  id: string;
  studentId: string;
  amountGnf: number;
  date: any;
}

export interface PaymentSummary {
  studentId: string;
  amountPaid: number;
  lastPaymentDate?: any;
}

export interface Attendance {
  [studentId: string]: 'present' | 'absent' | 'unknown';
}

interface SchoolGuardAppProps {
  initialLanguage?: Language;
}

export function SchoolGuardApp({ initialLanguage = 'fr' }: SchoolGuardAppProps) {
  const [activeTab, setActiveTab] = useState('dashboard');
  const [currency, setCurrency] = useState(DEVISE_DEFAULT);
  const [language, setLanguage] = useState(initialLanguage);
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<Student | null>(null);
  
  const firestore = useFirestore();
  const auth = useAuth();
  const { toast } = useToast();
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  // Data fetching from Firestore
  const studentsQuery = useMemo(() => query(collection(firestore, 'students'), orderBy('name', 'asc')), [firestore]);
  const { data: students } = useCollection<Student>(studentsQuery);

  const transactionsQuery = useMemo(() => query(collection(firestore, 'transactions'), orderBy('date', 'desc')), [firestore]);
  const { data: transactions } = useCollection<Transaction>(transactionsQuery);

  const todayStr = new Date().toISOString().split('T')[0];
  const attendanceDocRef = useMemo(() => doc(firestore, 'attendance', todayStr), [firestore, todayStr]);
  const { data: attendanceData } = useDoc<any>(attendanceDocRef);
  const attendance: Attendance = attendanceData?.records || {};

  const paymentsSummary = useMemo(() => {
    const summary: Record<string, PaymentSummary> = {};
    transactions.forEach(tx => {
      if (!summary[tx.studentId]) {
        summary[tx.studentId] = { studentId: tx.studentId, amountPaid: 0 };
      }
      summary[tx.studentId].amountPaid += tx.amountGnf;
    });
    return summary;
  }, [transactions]);

  const stats = useMemo(() => {
    const total = students.length;
    const present = Object.values(attendance).filter(v => v === 'present').length;
    const totalPaid = Object.values(paymentsSummary).reduce((acc, p) => acc + p.amountPaid, 0);
    const totalDue = total * FRAIS_SCOLARITE_BASE;
    return { total, present, totalPaid, totalDue };
  }, [students, attendance, paymentsSummary]);

  const handleSaveStudent = (studentData: Student) => {
    const sRef = doc(firestore, 'students', studentData.id);
    setDoc(sRef, { 
      ...studentData, 
      createdAt: studentData.createdAt || serverTimestamp() 
    }, { merge: true })
    .catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: sRef.path,
        operation: 'write',
        requestResourceData: studentData
      }));
    });
    setIsFormOpen(false);
    setEditingStudent(null);
  };

  const handleDeleteStudent = (id: string) => {
    const sRef = doc(firestore, 'students', id);
    deleteDoc(sRef).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: sRef.path,
        operation: 'delete'
      }));
    });
  };

  const handleMarkAttendance = (studentId: string, status: 'present' | 'absent') => {
    const newRecords = { ...attendance, [studentId]: status };
    setDoc(attendanceDocRef, { records: newRecords, date: todayStr }, { merge: true })
    .catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: attendanceDocRef.path,
        operation: 'update',
        requestResourceData: { records: newRecords }
      }));
    });
  };

  const handlePayment = (studentId: string, amountGnf: number) => {
    const txRef = collection(firestore, 'transactions');
    addDoc(txRef, {
      studentId,
      amountGnf,
      date: serverTimestamp(),
      currency: "GNF"
    }).catch(async () => {
      errorEmitter.emit('permission-error', new FirestorePermissionError({
        path: 'transactions',
        operation: 'create'
      }));
    });
  };

  const handleLogout = () => signOut(auth);

  return (
    <div className="container mx-auto p-4 md:p-8 space-y-8 max-w-7xl animate-in fade-in duration-500 min-h-screen flex flex-col" dir={isRtl ? 'rtl' : 'ltr'}>
      <header className="flex flex-col lg:flex-row justify-between items-start lg:items-center gap-6 no-print">
        <div className={`flex items-center gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className="w-14 h-14 bg-primary rounded-[1.25rem] flex items-center justify-center text-white shadow-xl shadow-primary/20 italic font-black text-2xl rotate-3">
            G
          </div>
          <div className={isRtl ? 'text-right' : ''}>
            <h1 className="text-2xl font-black tracking-tight text-foreground uppercase italic leading-none">
              {t.title}
            </h1>
            <p className={`text-muted-foreground text-[10px] font-bold uppercase tracking-[0.25em] mt-1.5 flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <ShieldCheck size={12} className="text-primary" /> {t.subtitle}
            </p>
          </div>
        </div>
        
        <div className={`flex flex-wrap items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className={`flex gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className={`flex items-center gap-2 bg-white border border-border px-4 py-3 rounded-2xl font-black transition-all shadow-sm active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <Languages size={16} /> {language.toUpperCase()}
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align={isRtl ? "start" : "end"} className="rounded-2xl max-h-[300px] overflow-y-auto">
                <DropdownMenuItem onClick={() => setLanguage('fr')}>FRANÇAIS</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('en')}>ENGLISH</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('es')}>ESPAÑOL</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('pt')}>PORTUGUÊS</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('it')}>ITALIANO</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('ar')}>العربية</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('nl')}>NEDERLANDS</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('adlam')}>𞤀𞤁𞤂𞤀𞤃</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setLanguage('nko')}>ߒߞߏ</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <button 
              onClick={() => setIsScannerOpen(true)}
              className={`flex items-center gap-2 bg-foreground hover:bg-black text-background px-5 py-3 rounded-2xl font-black transition-all shadow-xl active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <ScanLine size={16} /> {t.scanner}
            </button>
            <button 
              onClick={() => { setEditingStudent(null); setIsFormOpen(true); }}
              className={`flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-5 py-3 rounded-2xl font-black transition-all shadow-xl shadow-primary/20 active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}
            >
              <UserPlus size={16} /> {t.add}
            </button>

            <button 
              onClick={handleLogout}
              className={`flex items-center gap-2 bg-rose-50 text-rose-500 hover:bg-rose-100 px-5 py-3 rounded-2xl font-black transition-all active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}
              title={t.logout}
            >
              <LogOut size={16} /> {t.logout}
            </button>
          </div>
        </div>
      </header>

      <Tabs defaultValue="dashboard" value={activeTab} onValueChange={setActiveTab} className="space-y-8 no-print flex-grow">
        <div className="flex justify-center">
          <TabsList className={`bg-white p-1 h-auto rounded-2xl border border-border shadow-sm flex flex-wrap justify-center ${isRtl ? 'flex-row-reverse' : ''}`}>
            <TabsTrigger value="dashboard" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <LayoutDashboard className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.dashboard}
            </TabsTrigger>
            <TabsTrigger value="students" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <Users className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.students}
            </TabsTrigger>
            <TabsTrigger value="attendance" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <UserCheck className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.attendance}
            </TabsTrigger>
            <TabsTrigger value="finance" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <Wallet className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.finance}
            </TabsTrigger>
            <TabsTrigger value="certificates" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <FileText className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.certificates}
            </TabsTrigger>
            <TabsTrigger value="reports" className="rounded-xl px-6 py-2.5 font-black text-[10px] uppercase tracking-widest data-[state=active]:bg-primary data-[state=active]:text-white transition-all">
              <ClipboardList className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.reports}
            </TabsTrigger>
          </TabsList>
        </div>

        <TabsContent value="dashboard" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <DashboardOverview stats={stats} students={students} attendance={attendance} payments={paymentsSummary} currency={currency} language={language} />
        </TabsContent>

        <TabsContent value="students" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <StudentManagement 
            students={students} 
            payments={paymentsSummary}
            currency={currency}
            language={language}
            onEdit={(s) => { setEditingStudent(s); setIsFormOpen(true); }}
            onDelete={handleDeleteStudent}
            onPay={handlePayment}
          />
        </TabsContent>

        <TabsContent value="attendance" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <AttendanceTracking 
            students={students} 
            attendance={attendance} 
            language={language}
            onMark={handleMarkAttendance} 
          />
        </TabsContent>

        <TabsContent value="finance" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <FinanceManagement 
            students={students} 
            transactions={transactions} 
            payments={paymentsSummary}
            currency={currency}
            language={language}
            setCurrency={setCurrency}
            onPay={handlePayment}
          />
        </TabsContent>

        <TabsContent value="certificates" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <CertificateManagement 
            students={students}
            language={language}
          />
        </TabsContent>

        <TabsContent value="reports" className="space-y-8 animate-in fade-in slide-in-from-bottom-2 duration-300">
          <ReportManagement 
            students={students}
            language={language}
          />
        </TabsContent>
      </Tabs>

      <footer className="mt-12 py-10 border-t border-border flex flex-col items-center gap-4 text-center no-print animate-in fade-in duration-1000">
        <div className={`flex items-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className="w-8 h-8 bg-primary rounded-lg flex items-center justify-center text-white italic font-black text-sm">G</div>
          <p className="text-[10px] font-black text-foreground uppercase tracking-[0.2em]">
            {t.footer.createdBy}
          </p>
        </div>
        <div className={`flex flex-wrap justify-center gap-8 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-2 group ${isRtl ? 'flex-row-reverse' : ''}`}>
            <Phone size={14} className="text-primary group-hover:scale-110 transition-transform" />
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              {t.footer.phone}
            </p>
          </div>
          <div className={`flex items-center gap-2 group ${isRtl ? 'flex-row-reverse' : ''}`}>
            <Mail size={14} className="text-primary group-hover:scale-110 transition-transform" />
            <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">
              {t.footer.email}
            </p>
          </div>
        </div>
        <p className="text-[8px] font-bold text-muted-foreground/40 uppercase tracking-[0.5em] mt-2">
          © {new Date().getFullYear()} GARKI IB APP • VERSION 1.0
        </p>
      </footer>

      <QRScannerModal 
        isOpen={isScannerOpen} 
        onClose={() => setIsScannerOpen(false)} 
        students={students}
        language={language}
        onScan={handleMarkAttendance}
      />
      <StudentFormModal 
        isOpen={isFormOpen} 
        onClose={() => setIsFormOpen(false)} 
        onSave={handleSaveStudent}
        editingStudent={editingStudent}
        language={language}
      />
    </div>
  );
}
