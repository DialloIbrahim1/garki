"use client";

import React, { useState, useMemo } from 'react';
import { ClipboardList, Search, Calculator, Printer, Users as UsersIcon, CheckCircle2 } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { ReportPrintable } from './ReportPrintable';
import { cn } from '@/lib/utils';

interface ReportManagementProps {
  students: Student[];
  language: Language;
}

export type GradeRecord = Record<string, number>;

export function ReportManagement({ students, language }: ReportManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [grades, setGrades] = useState<GradeRecord>({
    math: 0,
    french: 0,
    physics: 0,
    biology: 0,
    history: 0,
    english: 0,
    philosophy: 0,
    sport: 0
  });
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  const filteredStudents = useMemo(() => {
    if (!searchTerm) return [];
    return students.filter(s => 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.id.toLowerCase().includes(searchTerm.toLowerCase())
    ).slice(0, 5);
  }, [students, searchTerm]);

  const average = useMemo(() => {
    const values = Object.values(grades);
    const sum = values.reduce((acc, val) => acc + val, 0);
    return (sum / values.length).toFixed(2);
  }, [grades]);

  const handleGradeChange = (subject: string, value: string) => {
    const num = parseFloat(value);
    if (!isNaN(num) && num >= 0 && num <= 20) {
      setGrades(prev => ({ ...prev, [subject]: num }));
    } else if (value === "") {
      setGrades(prev => ({ ...prev, [subject]: 0 }));
    }
  };

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      <header className={`flex flex-col gap-2 ${isRtl ? 'text-right' : ''}`}>
        <h2 className="text-2xl font-black text-foreground uppercase italic tracking-tight">{t.reportList.title}</h2>
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t.reportList.subtitle}</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Selection & Grading Column */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-border shadow-sm space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">{t.studentList.searchPlaceholder}</label>
              <div className="relative">
                <Search className={`absolute ${isRtl ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-muted-foreground/30`} size={18} />
                <input 
                  type="text" 
                  placeholder={t.studentList.searchPlaceholder}
                  className={`w-full ${isRtl ? 'pr-14 pl-6 text-right' : 'pl-14 pr-6'} py-4 bg-muted/30 border-none rounded-2xl outline-none text-sm font-bold focus:ring-2 focus:ring-primary transition-all`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {/* Suggestions */}
              {filteredStudents.length > 0 && (
                <div className="mt-2 bg-white border border-border rounded-2xl overflow-hidden shadow-xl animate-in fade-in slide-in-from-top-2">
                  {filteredStudents.map(s => (
                    <button 
                      key={s.id}
                      onClick={() => { setSelectedStudent(s); setSearchTerm(''); }}
                      className={cn(
                        "w-full p-4 text-left flex items-center gap-3 hover:bg-primary/5 transition-colors border-b border-border last:border-0",
                        isRtl ? "flex-row-reverse text-right" : ""
                      )}
                    >
                      <div className="w-10 h-10 rounded-xl bg-muted overflow-hidden">
                        {s.photo ? <img src={s.photo} className="w-full h-full object-cover" /> : <UsersIcon size={16} className="m-auto mt-3 text-muted-foreground/30" />}
                      </div>
                      <div>
                        <p className="text-sm font-black uppercase tracking-tight">{s.name}</p>
                        <p className="text-[9px] font-bold text-primary uppercase">{s.class}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            {selectedStudent && (
              <div className="space-y-4 pt-4 border-t border-border">
                <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">{language === 'fr' ? 'Saisie des Notes (0-20)' : 'Grade Entry (0-20)'}</label>
                <div className="grid grid-cols-2 gap-3">
                  {Object.keys(grades).map(subject => (
                    <div key={subject} className="space-y-1">
                      <p className="text-[8px] font-bold text-muted-foreground uppercase truncate">{t.reportList.subjects[subject]}</p>
                      <input 
                        type="number"
                        min="0"
                        max="20"
                        step="0.1"
                        className="w-full px-4 py-2 bg-muted/30 border-none rounded-xl outline-none text-xs font-black focus:ring-1 focus:ring-primary"
                        value={grades[subject]}
                        onChange={(e) => handleGradeChange(subject, e.target.value)}
                      />
                    </div>
                  ))}
                </div>

                <div className="bg-primary/5 p-4 rounded-2xl border border-primary/10 flex justify-between items-center">
                  <p className="text-[10px] font-black text-primary uppercase">{t.reportList.average}</p>
                  <p className="text-xl font-black text-primary">{average}</p>
                </div>
              </div>
            )}

            <button 
              disabled={!selectedStudent}
              onClick={() => setIsPreviewOpen(true)}
              className="w-full py-5 bg-primary text-white rounded-2xl font-black uppercase text-[11px] tracking-widest shadow-xl shadow-primary/20 hover:bg-primary/90 transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              <Printer size={18} /> {t.reportList.generate}
            </button>
          </div>
        </div>

        {/* Preview Column */}
        <div className="lg:col-span-2">
          {selectedStudent ? (
            <div className="bg-white rounded-[3rem] border border-border shadow-sm p-10 flex flex-col items-center text-center space-y-8 animate-in fade-in slide-in-from-right-4">
              <div className="w-24 h-24 rounded-[2rem] bg-emerald-50 text-emerald-500 flex items-center justify-center shadow-inner">
                <Calculator size={48} />
              </div>
              <div>
                <h3 className="text-xl font-black text-foreground uppercase tracking-tight">{selectedStudent.name}</h3>
                <div className="flex items-center gap-2 justify-center mt-1">
                  <p className="text-[10px] font-bold text-primary uppercase tracking-[0.2em]">{selectedStudent.class}</p>
                  <div className="w-1 h-1 bg-border rounded-full" />
                  <p className="text-[10px] font-bold text-emerald-500 uppercase tracking-[0.2em]">{t.reportList.average}: {average}</p>
                </div>
              </div>
              
              <div className="w-full max-w-md p-8 bg-muted/20 rounded-[2.5rem] border border-dashed border-border flex flex-col items-center gap-4">
                <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{t.certList.preview}</p>
                <div className="w-full bg-white rounded-2xl border border-border p-6 space-y-4">
                  <div className="flex justify-between border-b border-border pb-2">
                    <span className="text-[10px] font-black uppercase">{language === 'fr' ? 'MATIÈRE' : 'SUBJECT'}</span>
                    <span className="text-[10px] font-black uppercase">NOTE</span>
                  </div>
                  {Object.keys(grades).slice(0, 4).map(sub => (
                    <div key={sub} className="flex justify-between text-[10px] font-bold uppercase text-muted-foreground">
                      <span>{t.reportList.subjects[sub]}</span>
                      <span>{grades[sub]}</span>
                    </div>
                  ))}
                  <div className="pt-2 text-center">
                    <span className="text-[8px] italic opacity-40">...</span>
                  </div>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] bg-white rounded-[3rem] border border-border shadow-sm flex flex-col items-center justify-center p-12 text-center space-y-4 opacity-40">
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center text-muted-foreground/30">
                <ClipboardList size={40} />
              </div>
              <p className="text-sm font-black uppercase tracking-widest text-muted-foreground">{t.certList.noSelection}</p>
            </div>
          )}
        </div>
      </div>

      {/* Full Preview & Print Modal */}
      {selectedStudent && (
        <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
          <DialogContent className="max-w-fit p-0 bg-transparent border-none shadow-none no-scrollbar overflow-y-auto max-h-[90vh]">
            <ReportPrintable 
              student={selectedStudent}
              grades={grades}
              average={parseFloat(average)}
              language={language}
              onClose={() => setIsPreviewOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}
