"use client";

import React from 'react';
import { Printer, X, ShieldCheck, CheckCircle2, Calculator, BookOpen, GraduationCap } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';
import { GradeRecord } from './ReportManagement';

interface ReportPrintableProps {
  student: Student;
  grades: GradeRecord;
  average: number;
  language: Language;
  onClose: () => void;
}

export function ReportPrintable({ student, grades, average, language, onClose }: ReportPrintableProps) {
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';
  const today = new Date().toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const getRemark = (grade: number) => {
    if (grade >= 16) return language === 'fr' ? "Excellent" : "Excellent";
    if (grade >= 14) return language === 'fr' ? "Très Bien" : "Very Good";
    if (grade >= 12) return language === 'fr' ? "Assez Bien" : "Good";
    if (grade >= 10) return language === 'fr' ? "Passable" : "Fair";
    return language === 'fr' ? "Insuffisant" : "Insufficient";
  };

  return (
    <div className="relative flex flex-col items-center gap-6 animate-in zoom-in duration-300 max-w-full">
      {/* Report Sheet - Optimized for A4 */}
      <div id="report-printable" className={`w-[210mm] min-h-[297mm] bg-white p-16 relative overflow-hidden shadow-2xl print:shadow-none print:m-0 flex flex-col ${isRtl ? 'text-right' : 'text-left'}`}>
        
        {/* Subtle Background Security Pattern */}
        <div className="absolute inset-0 opacity-[0.02] pointer-events-none select-none" style={{ backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '30px 30px' }} />

        {/* Header Section */}
        <div className={`flex justify-between items-start mb-12 relative z-10 border-b-2 border-primary/20 pb-8 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <div className={`flex items-center gap-5 ${isRtl ? 'flex-row-reverse text-right' : 'text-left'}`}>
            <div className="w-20 h-20 bg-primary rounded-[1.5rem] flex items-center justify-center text-white italic font-black text-3xl rotate-3 shadow-2xl shadow-primary/20">G</div>
            <div>
              <h2 className="text-primary text-2xl font-black uppercase tracking-tight italic leading-none">IB GARKI DIALLO</h2>
              <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-[0.4em] mt-2">Groupe Scolaire d'Excellence</p>
              <div className="flex items-center gap-2 mt-2 opacity-60">
                <GraduationCap size={14} className="text-primary" />
                <span className="text-[9px] font-black uppercase tracking-widest">Enseignement Secondaire</span>
              </div>
            </div>
          </div>
          
          <div className={`flex flex-col ${isRtl ? 'items-start text-left' : 'items-end text-right'}`}>
            <div className="space-y-1">
              <p className="text-[10px] font-black text-foreground uppercase tracking-[0.2em]">RÉPUBLIQUE DE GUINÉE</p>
              <div className="flex items-center gap-2 justify-end">
                <div className="w-8 h-0.5 bg-red-500"></div>
                <div className="w-8 h-0.5 bg-yellow-400"></div>
                <div className="w-8 h-0.5 bg-green-500"></div>
              </div>
              <p className="text-[8px] font-bold text-primary uppercase tracking-widest mt-1">Travail - Justice - Solidarité</p>
            </div>
            <div className="mt-4 pt-4 border-t border-border w-full">
              <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest italic">Année Scolaire {new Date().getFullYear()} - {new Date().getFullYear() + 1}</p>
            </div>
          </div>
        </div>

        {/* Main Title Card */}
        <div className="w-full text-center mb-10">
          <h1 className="text-4xl font-black text-foreground uppercase tracking-tighter italic inline-block relative">
            {language === 'fr' ? 'RELEVÉ DE NOTES TRIMESTRIEL' : 'QUARTERLY GRADE REPORT'}
            <div className="absolute -bottom-2 left-0 right-0 h-1 bg-primary rounded-full opacity-20"></div>
          </h1>
        </div>

        {/* Student Data Box - MODERN GRID */}
        <div className="grid grid-cols-2 gap-px bg-border border border-border rounded-[2rem] overflow-hidden mb-12 shadow-sm">
          <div className="bg-white p-6">
            <p className="text-[8px] font-black text-primary/50 uppercase tracking-widest mb-1">{language === 'fr' ? 'ÉLÈVE' : 'STUDENT'}</p>
            <h3 className="text-2xl font-black text-foreground uppercase tracking-tight leading-tight">{student.name}</h3>
            <p className="text-[9px] font-bold text-muted-foreground uppercase mt-1 tracking-widest">ID: {student.id}</p>
          </div>
          <div className="bg-white p-6 flex flex-col justify-center">
            <div className="flex justify-between items-center mb-2">
              <span className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{t.modals.classLabel}</span>
              <span className="text-lg font-black text-primary uppercase">{student.class}</span>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{language === 'fr' ? 'PÉRIODE' : 'TERM'}</span>
              <span className="text-[10px] font-bold text-foreground uppercase">1er Trimestre</span>
            </div>
          </div>
        </div>

        {/* Grades Table - REFINED DESIGN */}
        <div className="flex-grow">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="p-5 text-[10px] font-black uppercase tracking-widest text-left text-muted-foreground border-b-2 border-primary/20">{language === 'fr' ? 'MATIÈRES' : 'SUBJECTS'}</th>
                <th className="p-5 text-[10px] font-black uppercase tracking-widest text-center text-muted-foreground border-b-2 border-primary/20">{t.reportList.grade} (/20)</th>
                <th className="p-5 text-[10px] font-black uppercase tracking-widest text-right text-muted-foreground border-b-2 border-primary/20">{language === 'fr' ? 'OBSERVATIONS' : 'REMARKS'}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {Object.keys(grades).map((subject, index) => {
                const grade = grades[subject];
                return (
                  <tr key={subject} className={index % 2 === 0 ? 'bg-transparent' : 'bg-muted/10'}>
                    <td className="p-5 text-sm font-black uppercase text-foreground tracking-tight">{t.reportList.subjects[subject]}</td>
                    <td className="p-5 text-base font-black text-center text-foreground">{grade.toFixed(2)}</td>
                    <td className="p-5 text-[10px] font-bold text-right italic text-muted-foreground">{getRemark(grade)}</td>
                  </tr>
                );
              })}
            </tbody>
            <tfoot>
              <tr className="bg-primary text-white shadow-xl">
                <td className="p-6 text-xl font-black uppercase tracking-widest text-left">{t.reportList.average}</td>
                <td className="p-6 text-3xl font-black text-center">{average.toFixed(2)}</td>
                <td className="p-6 text-sm font-black text-right uppercase tracking-widest">
                  {average >= 10 ? (language === 'fr' ? 'ADMIS(E)' : 'PASSED') : (language === 'fr' ? 'INSUFFISANT' : 'FAILED')}
                </td>
              </tr>
            </tfoot>
          </table>
        </div>

        {/* Footer Area - SIGNATURES & STAMP */}
        <div className="grid grid-cols-2 gap-20 pt-16 mt-auto">
          <div className="text-center">
            <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest mb-24">{language === 'fr' ? 'Le Parent / Tuteur' : 'Parent / Guardian'}</p>
            <div className="h-px w-40 bg-slate-200 mx-auto" />
            <p className="text-[7px] font-bold text-slate-300 uppercase mt-2 italic tracking-widest">Signature obligatoire</p>
          </div>
          <div className="text-center relative">
            <p className="text-[10px] font-black text-primary uppercase tracking-widest mb-6">La Direction Générale</p>
            <p className="text-sm font-bold text-foreground mb-4">Conakry, le {today}</p>
            
            {/* Visual Seal / Stamp Placeholder */}
            <div className="relative h-28 flex items-center justify-center">
              <div className="w-28 h-28 border-4 border-dashed border-primary/10 rounded-full flex flex-col items-center justify-center text-primary/10 rotate-12 bg-primary/[0.02]">
                 <ShieldCheck size={40} className="text-primary/10 mb-1" />
                 <span className="text-[8px] font-black uppercase tracking-tighter">SCEAU OFFICIEL</span>
                 <span className="text-[6px] font-black">{new Date().getFullYear()}</span>
              </div>
            </div>
            <div className="h-px w-40 bg-slate-200 mx-auto mt-4" />
          </div>
        </div>

        {/* Official Footer Disclaimer */}
        <div className="mt-16 flex justify-between items-center opacity-40 text-[7px] font-black text-foreground uppercase tracking-[0.3em] border-t border-border pt-8">
          <p>Bulletin généré par GARKI IB APP V1 • RÉF: BULL-{student.id.toUpperCase()}</p>
          <div className="flex gap-4">
            <span>Discipline: Exemplaire</span>
            <span>Assiduité: Satisfaisante</span>
          </div>
          <p>© {new Date().getFullYear()} IB GARKI DIALLO</p>
        </div>
      </div>

      {/* Action Buttons - NO PRINT */}
      <div className="flex gap-4 w-full max-w-md no-print mb-12">
        <button 
          onClick={onClose} 
          className="flex-1 px-10 py-5 bg-white border border-border text-foreground hover:bg-muted rounded-3xl font-black uppercase text-[11px] tracking-widest transition-all shadow-sm active:scale-95"
        >
          {t.modals.cancel}
        </button>
        <button 
          onClick={() => window.print()} 
          className="flex-[2] px-10 py-5 bg-primary text-white rounded-3xl font-black uppercase text-[11px] tracking-widest flex items-center justify-center gap-3 shadow-2xl shadow-primary/20 transition-all active:scale-95"
        >
          <Printer size={20} /> {t.reportList.print}
        </button>
      </div>
    </div>
  );
}
