
"use client";

import React from 'react';
import { ShieldCheck, ArrowRight, Languages, Sparkles, Info } from 'lucide-react';
import { translations, Language } from '@/lib/translations';
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";

interface LoginProps {
  language: Language;
  onLanguageChange: (lang: Language) => void;
  onGuestAccess: () => void;
}

export function Login({ language, onLanguageChange, onGuestAccess }: LoginProps) {
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  return (
    <div className="min-h-screen bg-background flex items-center justify-center p-6" dir={isRtl ? 'rtl' : 'ltr'}>
      <div className="w-full max-w-md space-y-8 animate-in fade-in zoom-in duration-500">
        <div className="flex flex-col items-center text-center gap-6">
          <div className="w-20 h-20 bg-primary rounded-[1.8rem] flex items-center justify-center text-white shadow-2xl shadow-primary/20 italic font-black text-4xl rotate-3">
            G
          </div>
          <div>
            <h1 className="text-3xl font-black tracking-tight text-foreground uppercase italic leading-none">
              {t.title}
            </h1>
            <p className="text-muted-foreground text-[10px] font-bold uppercase tracking-[0.25em] mt-3 flex items-center justify-center gap-2">
              <ShieldCheck size={12} className="text-primary" /> {t.subtitle}
            </p>
          </div>
        </div>

        <div className="bg-white p-8 rounded-[3rem] border border-border shadow-xl space-y-8">
          <div className="space-y-4">
            <h2 className="text-center text-[10px] font-black text-muted-foreground uppercase tracking-[0.3em]">
              {language === 'fr' ? 'ACCÈS DIRECT AU SYSTÈME' : 'DIRECT SYSTEM ACCESS'}
            </h2>
            <button
              onClick={onGuestAccess}
              className="w-full py-7 bg-primary text-white rounded-[2rem] font-black uppercase text-[12px] tracking-[0.2em] shadow-2xl shadow-primary/30 hover:bg-primary/90 hover:scale-[1.02] active:scale-95 transition-all flex items-center justify-center gap-4"
            >
              <Sparkles size={20} /> 
              {language === 'fr' ? 'ENTRER MAINTENANT' : 'ENTER NOW'}
              <ArrowRight size={20} className={isRtl ? 'rotate-180' : ''} />
            </button>
          </div>

          <div className="p-5 bg-blue-50 rounded-2xl border border-blue-100 flex gap-4 items-start">
            <Info size={18} className="text-blue-600 shrink-0 mt-0.5" />
            <div className="space-y-1">
              <p className="text-[9px] font-black text-blue-600 uppercase tracking-widest">
                {language === 'fr' ? 'MODE LIBRE ACTIVÉ' : 'FREE MODE ACTIVE'}
              </p>
              <p className="text-[8px] text-blue-800 font-bold uppercase leading-tight">
                {language === 'fr' 
                  ? 'Cliquez sur le bouton ci-dessus pour accéder à toutes les fonctionnalités sans identifiants.' 
                  : 'Click the button above to access all features without credentials.'}
              </p>
            </div>
          </div>
        </div>

        <div className="flex justify-center">
          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <button className={`flex items-center gap-2 bg-white/50 backdrop-blur-sm border border-border px-4 py-3 rounded-2xl font-black transition-all shadow-sm active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}>
                <Languages size={16} /> {language.toUpperCase()}
              </button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="center" className="rounded-2xl max-h-[300px] overflow-y-auto">
              <DropdownMenuItem onClick={() => onLanguageChange('fr')}>FRANÇAIS</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('en')}>ENGLISH</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('es')}>ESPAÑOL</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('pt')}>PORTUGUÊS</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('it')}>ITALIANO</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('ar')}>العربية</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('nl')}>NEDERLANDS</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('adlam')}>𞤀𞤁𞤂𞤀𞤃</DropdownMenuItem>
              <DropdownMenuItem onClick={() => onLanguageChange('nko')}>ߒߞߏ</DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>
      </div>
    </div>
  );
}
