"use client";

import React from 'react';
import { Award, Printer, ShieldCheck, FileText, CheckCircle2 } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';

interface CertificatePrintableProps {
  student: Student;
  type: 'attendance' | 'excellence' | 'conduct';
  language: Language;
  onClose: () => void;
}

export function CertificatePrintable({ student, type, language, onClose }: CertificatePrintableProps) {
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';
  const today = new Date().toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const getTitle = () => {
    switch (type) {
      case 'excellence': return t.certList.types.excellence;
      case 'conduct': return t.certList.types.conduct;
      default: return t.certList.types.attendance;
    }
  };

  const getContent = () => {
    if (language === 'fr') {
      switch (type) {
        case 'excellence':
          return `Est décerné à ${student.name}, élève en classe de ${student.class}, pour ses résultats académiques exceptionnels et son engagement exemplaire au sein de l'établissement IB Garki Diallo.`;
        case 'conduct':
          return `Atteste que ${student.name}, élève en classe de ${student.class}, a fait preuve d'une discipline irréprochable et d'un comportement citoyen durant l'année scolaire en cours.`;
        default:
          return `Certifie que ${student.name} est régulièrement inscrit(e) en classe de ${student.class} au sein de l'établissement IB Garki Diallo pour l'année scolaire en cours.`;
      }
    }
    switch (type) {
      case 'excellence':
        return `Is awarded to ${student.name}, student in ${student.class}, for outstanding academic achievements and exemplary commitment at IB Garki Diallo.`;
      case 'conduct':
        return `Certifies that ${student.name}, student in ${student.class}, has demonstrated impeccable discipline and citizenship during the current school year.`;
      default:
        return `Certifies that ${student.name} is regularly enrolled in ${student.class} at IB Garki Diallo for the current school year.`;
    }
  };

  return (
    <div className="relative flex flex-col items-center gap-6 animate-in zoom-in duration-300 max-w-full">
      {/* Certificate Sheet - MODERN PROFESSIONAL GOLD & BLACK */}
      <div id="certificate-printable" className="w-[210mm] min-h-[297mm] bg-white p-2 relative overflow-hidden shadow-2xl print:shadow-none print:m-0 flex items-center justify-center">
        
        {/* Modern Geometric Gold Border */}
        <div className="absolute inset-0 border-[16px] border-black">
           <div className="absolute inset-0 border-[2px] border-[#D4AF37] m-1"></div>
        </div>

        {/* Decorative Corner Ornaments */}
        <div className="absolute top-0 left-0 w-40 h-40">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-[#D4AF37]">
            <path d="M0 0 L100 0 L0 100 Z" opacity="0.1" />
            <path d="M0 0 L40 0 L0 40 Z" />
          </svg>
        </div>
        <div className="absolute top-0 right-0 w-40 h-40 rotate-90">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-[#D4AF37]">
            <path d="M0 0 L100 0 L0 100 Z" opacity="0.1" />
            <path d="M0 0 L40 0 L0 40 Z" />
          </svg>
        </div>
        <div className="absolute bottom-0 left-0 w-40 h-40 -rotate-90">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-[#D4AF37]">
            <path d="M0 0 L100 0 L0 100 Z" opacity="0.1" />
            <path d="M0 0 L40 0 L0 40 Z" />
          </svg>
        </div>
        <div className="absolute bottom-0 right-0 w-40 h-40 rotate-180">
          <svg viewBox="0 0 100 100" className="w-full h-full fill-[#D4AF37]">
            <path d="M0 0 L100 0 L0 100 Z" opacity="0.1" />
            <path d="M0 0 L40 0 L0 40 Z" />
          </svg>
        </div>

        {/* Main Content Area */}
        <div className="relative z-10 w-[88%] h-[90%] flex flex-col p-12 text-center">
          
          {/* Subtle Background Pattern */}
          <div className="absolute inset-0 opacity-[0.03] pointer-events-none select-none" style={{ backgroundImage: 'radial-gradient(circle, #000 1px, transparent 1px)', backgroundSize: '20px 20px' }} />

          {/* Header */}
          <div className="flex flex-col items-center mb-10">
            <div className="flex items-center gap-4 mb-4">
              <div className="w-16 h-16 bg-black rounded-2xl flex items-center justify-center text-[#D4AF37] italic font-black text-3xl rotate-3 shadow-lg">G</div>
              <div className="text-left">
                <h2 className="text-black text-xl font-black uppercase tracking-widest leading-none">IB GARKI DIALLO</h2>
                <p className="text-[10px] font-bold text-[#D4AF37] uppercase tracking-[0.4em] mt-1">Établissement d'Excellence</p>
              </div>
            </div>
            <div className="w-24 h-1 bg-[#D4AF37] rounded-full"></div>
          </div>

          {/* Certificate Body */}
          <div className="flex-1 flex flex-col items-center justify-center space-y-8">
            <h1 className="text-6xl font-black text-black uppercase tracking-tight mb-2">
              CERTIFICAT
            </h1>
            <div className="bg-black text-[#D4AF37] px-8 py-2 rounded-full text-lg font-black uppercase tracking-[0.3em] inline-block">
              {getTitle()}
            </div>

            <p className="text-sm font-bold text-slate-400 uppercase tracking-[0.4em] mt-12">Le présent document est décerné à</p>
            
            <div className="relative">
              <h2 className="text-5xl font-serif italic font-black text-black py-4 border-b-2 border-black/10 px-10">
                {student.name}
              </h2>
            </div>

            <p className="text-xl font-medium text-slate-700 leading-relaxed max-w-2xl px-10">
              {getContent()}
            </p>
          </div>

          {/* Medallion / Seal in Footer */}
          <div className="flex justify-center mb-12">
            <div className="w-28 h-28 bg-[#D4AF37] rounded-full border-4 border-white shadow-2xl flex flex-col items-center justify-center text-black">
              <ShieldCheck size={40} strokeWidth={2.5} />
              <span className="text-[8px] font-black uppercase mt-1">OFFICIEL</span>
              <span className="text-[10px] font-black">{new Date().getFullYear()}</span>
            </div>
          </div>

          {/* Footer Signatures */}
          <div className="grid grid-cols-2 gap-32 border-t border-slate-100 pt-8">
            <div className="text-center">
              <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest mb-16">Le Tuteur / Parent</p>
              <div className="w-32 h-px bg-slate-200 mx-auto"></div>
            </div>
            <div className="text-center relative">
              <p className="text-[10px] font-black text-black uppercase tracking-widest mb-16">La Direction Générale</p>
              <div className="w-32 h-px bg-slate-200 mx-auto"></div>
              <p className="absolute -bottom-6 left-0 right-0 text-[9px] font-bold text-slate-400">Conakry, le {today}</p>
            </div>
          </div>

          {/* Verification Code */}
          <div className="mt-12 flex justify-between items-center text-[7px] font-black text-slate-300 uppercase tracking-widest">
            <p>ID: {student.id.toUpperCase()}</p>
            <p>Ce document est généré électroniquement par GARKI IB APP V1</p>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className="flex gap-4 w-full max-w-md no-print mb-12">
        <button 
          onClick={onClose} 
          className="flex-1 px-10 py-5 bg-white border border-border text-foreground hover:bg-muted rounded-3xl font-black uppercase text-[11px] tracking-widest transition-all shadow-sm active:scale-95"
        >
          {t.modals.cancel}
        </button>
        <button 
          onClick={() => window.print()} 
          className="flex-[2] px-10 py-5 bg-black text-[#D4AF37] border-2 border-[#D4AF37] rounded-3xl font-black uppercase text-[11px] tracking-widest flex items-center justify-center gap-3 shadow-2xl hover:bg-slate-900 transition-all active:scale-95"
        >
          <Printer size={20} /> {t.certList.print}
        </button>
      </div>
    </div>
  );
}
