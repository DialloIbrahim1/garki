"use client";

import React, { useState, useMemo } from 'react';
import { FileText, Search, Award, ShieldCheck, Printer, Users as UsersIcon, CheckCircle2 } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { CertificatePrintable } from './CertificatePrintable';
import { cn } from '@/lib/utils';

interface CertificateManagementProps {
  students: Student[];
  language: Language;
}

type CertificateType = 'attendance' | 'excellence' | 'conduct';

export function CertificateManagement({ students, language }: CertificateManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedStudent, setSelectedStudent] = useState<Student | null>(null);
  const [certType, setCertType] = useState<CertificateType>('attendance');
  const [isPreviewOpen, setIsPreviewOpen] = useState(false);
  
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  const filteredStudents = useMemo(() => {
    if (!searchTerm) return [];
    return students.filter(s => 
      s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
      s.id.toLowerCase().includes(searchTerm.toLowerCase())
    ).slice(0, 5);
  }, [students, searchTerm]);

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      <header className={`flex flex-col gap-2 ${isRtl ? 'text-right' : ''}`}>
        <h2 className="text-2xl font-black text-foreground uppercase italic tracking-tight">{t.certList.title}</h2>
        <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest">{t.certList.subtitle}</p>
      </header>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Selection Column */}
        <div className="lg:col-span-1 space-y-6">
          <div className="bg-white p-8 rounded-[2.5rem] border border-border shadow-sm space-y-6">
            <div className="space-y-2">
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">{t.certList.searchPlaceholder}</label>
              <div className="relative">
                <Search className={`absolute ${isRtl ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-muted-foreground/30`} size={18} />
                <input 
                  type="text" 
                  placeholder={t.certList.searchPlaceholder}
                  className={`w-full ${isRtl ? 'pr-14 pl-6 text-right' : 'pl-14 pr-6'} py-4 bg-muted/30 border-none rounded-2xl outline-none text-sm font-bold focus:ring-2 focus:ring-primary transition-all`}
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />
              </div>

              {/* Suggestions */}
              {filteredStudents.length > 0 && (
                <div className="mt-2 bg-white border border-border rounded-2xl overflow-hidden shadow-xl animate-in fade-in slide-in-from-top-2">
                  {filteredStudents.map(s => (
                    <button 
                      key={s.id}
                      onClick={() => { setSelectedStudent(s); setSearchTerm(''); }}
                      className={cn(
                        "w-full p-4 text-left flex items-center gap-3 hover:bg-primary/5 transition-colors border-b border-border last:border-0",
                        isRtl ? "flex-row-reverse text-right" : ""
                      )}
                    >
                      <div className="w-10 h-10 rounded-xl bg-muted overflow-hidden">
                        {s.photo ? <img src={s.photo} className="w-full h-full object-cover" /> : <UsersIcon size={16} className="m-auto mt-3 text-muted-foreground/30" />}
                      </div>
                      <div>
                        <p className="text-sm font-black uppercase tracking-tight">{s.name}</p>
                        <p className="text-[9px] font-bold text-primary uppercase">{s.class}</p>
                      </div>
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div className="space-y-4">
              <label className="text-[10px] font-black text-muted-foreground uppercase tracking-widest px-1">{t.certList.typeLabel}</label>
              <div className="grid grid-cols-1 gap-2">
                <CertTypeButton 
                  active={certType === 'attendance'} 
                  onClick={() => setCertType('attendance')} 
                  icon={<FileText size={18} />} 
                  label={t.certList.types.attendance}
                  isRtl={isRtl}
                />
                <CertTypeButton 
                  active={certType === 'excellence'} 
                  onClick={() => setCertType('excellence')} 
                  icon={<Award size={18} />} 
                  label={t.certList.types.excellence}
                  isRtl={isRtl}
                />
                <CertTypeButton 
                  active={certType === 'conduct'} 
                  onClick={() => setCertType('conduct')} 
                  icon={<ShieldCheck size={18} />} 
                  label={t.certList.types.conduct}
                  isRtl={isRtl}
                />
              </div>
            </div>

            <button 
              disabled={!selectedStudent}
              onClick={() => setIsPreviewOpen(true)}
              className="w-full py-5 bg-primary text-white rounded-2xl font-black uppercase text-[11px] tracking-widest shadow-xl shadow-primary/20 hover:bg-primary/90 transition-all disabled:opacity-30 disabled:cursor-not-allowed flex items-center justify-center gap-3"
            >
              <Printer size={18} /> {t.certList.generate}
            </button>
          </div>
        </div>

        {/* Preview Column */}
        <div className="lg:col-span-2">
          {selectedStudent ? (
            <div className="bg-white rounded-[3rem] border border-border shadow-sm p-10 flex flex-col items-center text-center space-y-8 animate-in fade-in slide-in-from-right-4">
              <div className="w-24 h-24 rounded-[2rem] bg-emerald-50 text-emerald-500 flex items-center justify-center shadow-inner">
                <CheckCircle2 size={48} />
              </div>
              <div>
                <h3 className="text-xl font-black text-foreground uppercase tracking-tight">{selectedStudent.name}</h3>
                <p className="text-[10px] font-bold text-primary uppercase tracking-[0.2em] mt-1">{selectedStudent.class}</p>
              </div>
              
              <div className="w-full max-w-md p-8 bg-muted/20 rounded-[2.5rem] border border-dashed border-border flex flex-col items-center gap-4">
                <p className="text-[9px] font-black text-muted-foreground uppercase tracking-widest">{t.certList.preview}</p>
                <div className="w-full h-40 bg-white rounded-2xl border border-border flex flex-col items-center justify-center gap-2">
                  <FileText className="text-primary/20" size={48} />
                  <p className="text-[10px] font-bold uppercase text-primary/40">{t.certList.types[certType]}</p>
                </div>
              </div>
            </div>
          ) : (
            <div className="h-full min-h-[400px] bg-white rounded-[3rem] border border-border shadow-sm flex flex-col items-center justify-center p-12 text-center space-y-4 opacity-40">
              <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center text-muted-foreground/30">
                <FileText size={40} />
              </div>
              <p className="text-sm font-black uppercase tracking-widest text-muted-foreground">{t.certList.noSelection}</p>
            </div>
          )}
        </div>
      </div>

      {/* Full Preview & Print Modal */}
      {selectedStudent && (
        <Dialog open={isPreviewOpen} onOpenChange={setIsPreviewOpen}>
          <DialogContent className="max-w-fit p-0 bg-transparent border-none shadow-none no-scrollbar overflow-y-auto max-h-[90vh]">
            <CertificatePrintable 
              student={selectedStudent}
              type={certType}
              language={language}
              onClose={() => setIsPreviewOpen(false)}
            />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function CertTypeButton({ active, onClick, icon, label, isRtl }: any) {
  return (
    <button 
      onClick={onClick}
      className={cn(
        "w-full px-5 py-4 rounded-xl flex items-center gap-3 text-[10px] font-black uppercase tracking-widest transition-all border",
        active ? "bg-primary text-white border-primary shadow-lg shadow-primary/10" : "bg-muted/50 text-muted-foreground border-transparent hover:bg-muted",
        isRtl ? "flex-row-reverse text-right" : ""
      )}
    >
      <div className={active ? "text-white" : "text-primary"}>{icon}</div>
      {label}
    </button>
  );
}