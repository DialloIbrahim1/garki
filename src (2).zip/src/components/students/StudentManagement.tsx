
"use client";

import React, { useState, useMemo } from 'react';
import { Search, Filter, Edit3, Trash2, IdCard, Banknote, Check, Droplet, Users as UsersIcon } from 'lucide-react';
import { Student, Payment } from '../SchoolGuardApp';
import { CLASSES, FRAIS_SCOLARITE_BASE } from '@/lib/constants';
import { IDCardPrintable } from './IDCardPrintable';
import { Dialog, DialogContent } from '@/components/ui/dialog';
import { Language, translations } from '@/lib/translations';

interface StudentManagementProps {
  students: Student[];
  payments: Record<string, Payment>;
  currency: string;
  language: Language;
  onEdit: (s: Student) => void;
  onDelete: (id: string) => void;
  onPay: (id: string, amount: number) => void;
}

export function StudentManagement({ students, payments, currency, language, onEdit, onDelete, onPay }: StudentManagementProps) {
  const [searchTerm, setSearchTerm] = useState('');
  const [filterClass, setFilterClass] = useState('Toutes');
  const [selectedStudentForID, setSelectedStudentForID] = useState<Student | null>(null);
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  const filteredStudents = useMemo(() => {
    return students.filter(s => {
      const matchSearch = s.name.toLowerCase().includes(searchTerm.toLowerCase()) || 
                          s.id.toLowerCase().includes(searchTerm.toLowerCase());
      const matchClass = filterClass === 'Toutes' || s.class === filterClass;
      return matchSearch && matchClass;
    });
  }, [students, searchTerm, filterClass]);

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Filters */}
      <div className={`bg-white p-4 rounded-[2.5rem] border border-border shadow-sm flex flex-col lg:flex-row gap-4 ${isRtl ? 'lg:flex-row-reverse' : ''}`}>
        <div className="relative flex-1">
          <Search className={`absolute ${isRtl ? 'right-5' : 'left-5'} top-1/2 -translate-y-1/2 text-muted-foreground`} size={18} />
          <input 
            type="text" 
            placeholder={t.studentList.searchPlaceholder}
            className={`w-full ${isRtl ? 'pr-14 pl-6 text-right' : 'pl-14 pr-6'} py-4 bg-background border-none rounded-2xl focus:ring-2 focus:ring-primary outline-none text-sm font-bold`}
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </div>
        <div className={`flex gap-2 overflow-x-auto no-scrollbar pb-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <FilterButton label={t.studentList.allClasses} active={filterClass === 'Toutes'} onClick={() => setFilterClass('Toutes')} />
          {CLASSES.map(c => (
            <FilterButton key={c} label={c} active={filterClass === c} onClick={() => setFilterClass(c)} />
          ))}
        </div>
      </div>

      {/* Grid */}
      {filteredStudents.length > 0 ? (
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-8">
          {filteredStudents.map(s => (
            <StudentCard 
              key={s.id} 
              student={s} 
              amountPaid={payments[s.id]?.amountPaid || 0}
              currency={currency}
              language={language}
              onEdit={() => onEdit(s)}
              onDelete={() => onDelete(s.id)}
              onPrint={() => setSelectedStudentForID(s)}
              onPay={() => onPay(s.id, 500000)}
            />
          ))}
        </div>
      ) : (
        <div className="bg-white rounded-[3rem] p-20 text-center space-y-4">
          <UsersIcon className="mx-auto h-16 w-16 text-muted-foreground/20" />
          <h3 className="text-xl font-black text-muted-foreground uppercase">{t.studentList.noStudent}</h3>
          <p className="text-muted-foreground max-w-xs mx-auto">{t.studentList.addFirst}</p>
        </div>
      )}

      {/* ID Card Modal */}
      {selectedStudentForID && (
        <Dialog open={!!selectedStudentForID} onOpenChange={() => setSelectedStudentForID(null)}>
          <DialogContent className="max-w-fit p-0 bg-transparent border-none shadow-none">
            <IDCardPrintable student={selectedStudentForID} language={language} onClose={() => setSelectedStudentForID(null)} />
          </DialogContent>
        </Dialog>
      )}
    </div>
  );
}

function FilterButton({ label, active, onClick }: { label: string, active: boolean, onClick: () => void }) {
  return (
    <button 
      onClick={onClick} 
      className={`px-5 py-2.5 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all whitespace-nowrap ${active ? 'bg-primary text-white shadow-lg' : 'bg-background text-muted-foreground hover:bg-muted'}`}
    >
      {label}
    </button>
  );
}

function StudentCard({ student, amountPaid, currency, language, onEdit, onDelete, onPrint, onPay }: { 
  student: Student, 
  amountPaid: number,
  currency: string,
  language: Language,
  onEdit: () => void,
  onDelete: () => void,
  onPrint: () => void,
  onPay: () => void
}) {
  const isPaid = amountPaid >= FRAIS_SCOLARITE_BASE;
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';
  
  return (
    <div className={`bg-white rounded-[2.5rem] border border-border shadow-sm overflow-hidden group hover:border-primary/30 transition-all duration-500 hover:shadow-2xl hover:translate-y-[-8px] ${isRtl ? 'text-right' : ''}`}>
      <div className="relative h-56 bg-muted overflow-hidden">
        {student.photo ? (
          <img src={student.photo} alt={student.name} className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-110" />
        ) : (
          <div className="w-full h-full flex items-center justify-center text-muted-foreground/20 bg-muted">
            <UsersIcon size={64} />
          </div>
        )}
        
        <div className={`absolute top-5 ${isRtl ? 'right-5' : 'left-5'} flex flex-col gap-2`}>
          <div className="bg-white/95 backdrop-blur px-3 py-1.5 rounded-xl text-[9px] font-black text-primary uppercase shadow-sm">
            {student.class}
          </div>
          <div className={`bg-rose-500/90 backdrop-blur px-3 py-1.5 rounded-xl text-[9px] font-black text-white uppercase shadow-sm flex items-center gap-1 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <Droplet size={10} fill="white"/> {student.bloodGroup}
          </div>
        </div>

        <div className={`absolute top-5 ${isRtl ? 'left-5' : 'right-5'} flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity ${isRtl ? 'flex-row-reverse' : ''}`}>
          <button onClick={onEdit} className="p-3 bg-white/95 backdrop-blur rounded-2xl text-muted-foreground hover:text-primary transition-colors shadow-lg">
            <Edit3 size={16} />
          </button>
          <button onClick={onDelete} className="p-3 bg-white/95 backdrop-blur rounded-2xl text-muted-foreground hover:text-destructive transition-colors shadow-lg">
            <Trash2 size={16} />
          </button>
        </div>
      </div>

      <div className="p-7 space-y-6">
        <div>
          <h4 className="text-lg font-black text-foreground uppercase truncate tracking-tight">{student.name}</h4>
          <p className="text-[10px] font-bold text-muted-foreground tracking-widest mt-1">ID: {student.id}</p>
        </div>
        
        <div className={`flex gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
          <button 
            onClick={onPrint} 
            className={`flex-1 bg-background text-muted-foreground hover:text-primary py-4 rounded-2xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all border border-transparent hover:border-primary/20 ${isRtl ? 'flex-row-reverse' : ''}`}
          >
            <IdCard size={18} /> {t.studentList.idCard}
          </button>
          <button 
            onClick={onPay} 
            disabled={isPaid}
            className={`flex-[1.5] py-4 rounded-2xl text-[9px] font-black uppercase tracking-widest flex items-center justify-center gap-2 transition-all ${isPaid ? 'bg-emerald-50 text-emerald-600' : 'bg-primary text-white shadow-xl shadow-primary/20 hover:bg-primary/90 active:scale-95'} ${isRtl ? 'flex-row-reverse' : ''}`}
          >
            {isPaid ? <Check size={18}/> : <Banknote size={18} />} {isPaid ? t.studentList.paid : t.studentList.pay}
          </button>
        </div>
      </div>
    </div>
  );
}
