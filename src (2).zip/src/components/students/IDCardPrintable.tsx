"use client";

import React from 'react';
import { QrCode, Droplet, Printer, Phone, MapPin, Heart } from 'lucide-react';
import { Student } from '../SchoolGuardApp';
import { Language, translations } from '@/lib/translations';

interface IDCardPrintableProps {
  student: Student;
  language: Language;
  onClose: () => void;
}

export function IDCardPrintable({ student, language, onClose }: IDCardPrintableProps) {
  const qrUrl = `https://api.qrserver.com/v1/create-qr-code/?size=150x150&data=${student.id}`;
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  return (
    <div className="relative flex flex-col items-center gap-8 animate-in zoom-in duration-300">
      {/* Container with a standard ID card ratio */}
      <div id="id-card" className={`w-[500px] h-[300px] bg-white rounded-[2.5rem] relative overflow-hidden shadow-2xl flex border border-border print:m-0 print:border-none print:shadow-none ${isRtl ? 'flex-row-reverse text-right' : ''}`}>
        
        {/* Decorative Side Panel */}
        <div className={`w-[180px] bg-primary relative flex flex-col items-center justify-between p-6 ${isRtl ? 'order-2' : ''}`}>
          <div className="w-full flex justify-center">
            <div className="w-10 h-10 bg-white rounded-xl flex items-center justify-center text-primary italic font-black text-xl rotate-3 shadow-lg">G</div>
          </div>
          
          <div className="w-32 h-40 bg-white rounded-[1.8rem] p-1.5 shadow-2xl overflow-hidden border-2 border-white/20">
             {student.photo ? (
               <img src={student.photo} className="w-full h-full object-cover rounded-[1.4rem]" />
             ) : (
               <div className="w-full h-full bg-muted flex items-center justify-center text-muted-foreground/20">
                 <QrCode size={40} />
               </div>
             )}
          </div>
          
          <div className="w-full flex flex-col items-center gap-2">
            <div className="bg-white/10 px-4 py-1.5 rounded-full backdrop-blur-sm">
              <p className="text-[10px] font-black text-white uppercase tracking-wider">{student.class}</p>
            </div>
          </div>
        </div>

        {/* Content Panel */}
        <div className={`flex-1 p-8 flex flex-col bg-white relative ${isRtl ? 'text-right' : ''}`}>
          <div className={`flex justify-between items-start mb-6 ${isRtl ? 'flex-row-reverse' : ''}`}>
             <div>
               <h3 className="text-primary text-[11px] font-black uppercase tracking-[0.2em] italic leading-tight">{t.title}</h3>
               <p className="text-[7px] font-bold text-muted-foreground uppercase tracking-widest mt-1">{t.subtitle}</p>
             </div>
             <div className="w-20 h-20 bg-muted/30 p-2 rounded-2xl border border-border flex items-center justify-center group hover:bg-white transition-colors">
               <img src={qrUrl} alt="QR Code" className="w-full h-full mix-blend-multiply" />
             </div>
          </div>
          
          <div className="flex-1 space-y-4">
            <div>
              <p className="text-[8px] font-black text-primary/40 uppercase tracking-widest mb-1">{language === 'fr' ? 'NOM COMPLET' : 'FULL NAME'}</p>
              <h4 className="text-2xl font-black text-foreground uppercase tracking-tighter leading-tight">{student.name}</h4>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <div className="w-8 h-8 rounded-lg bg-rose-50 flex items-center justify-center text-rose-500">
                  <Heart size={14} fill="currentColor" />
                </div>
                <div>
                  <p className="text-[7px] font-black text-muted-foreground uppercase">{t.modals.bloodLabel}</p>
                  <p className="text-[10px] font-bold text-foreground">{student.bloodGroup}</p>
                </div>
              </div>
              <div className={`flex items-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
                <div className="w-8 h-8 rounded-lg bg-emerald-50 flex items-center justify-center text-emerald-500">
                  <Phone size={14} fill="currentColor" />
                </div>
                <div>
                  <p className="text-[7px] font-black text-muted-foreground uppercase">ID CARD</p>
                  <p className="text-[10px] font-bold text-foreground truncate max-w-[80px]">{student.id}</p>
                </div>
              </div>
            </div>
          </div>

          <div className={`mt-auto pt-4 border-t border-dashed border-border flex justify-between items-center ${isRtl ? 'flex-row-reverse' : ''}`}>
             <div className={`flex items-center gap-2 text-muted-foreground ${isRtl ? 'flex-row-reverse' : ''}`}>
               <Phone size={10} />
               <p className="text-[9px] font-black tracking-tight">{student.phoneWhatsapp}</p>
             </div>
             <div className={`flex items-center gap-2 text-muted-foreground ${isRtl ? 'flex-row-reverse' : ''}`}>
               <MapPin size={10} />
               <p className="text-[9px] font-black tracking-tight">IB GARKI</p>
             </div>
          </div>
        </div>
      </div>

      {/* Action Buttons */}
      <div className={`flex gap-4 w-full max-w-[500px] no-print ${isRtl ? 'flex-row-reverse' : ''}`}>
        <button onClick={onClose} className="flex-1 px-8 py-5 bg-white/10 text-white hover:bg-white/20 rounded-3xl font-black uppercase text-[10px] transition-all">{t.modals.cancel}</button>
        <button 
          onClick={() => window.print()} 
          className={`flex-[2] px-8 py-5 bg-primary text-white rounded-3xl font-black uppercase text-[10px] flex items-center justify-center gap-3 shadow-2xl shadow-primary/40 hover:bg-primary/90 transition-all ${isRtl ? 'flex-row-reverse' : ''}`}
        >
          <Printer size={18} /> {language === 'fr' ? "IMPRIMER CARTE" : "PRINT ID CARD"}
        </button>
      </div>
    </div>
  );
}
