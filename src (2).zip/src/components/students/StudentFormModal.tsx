
"use client";

import React, { useState, useRef, useEffect } from 'react';
import { X, Camera, Save, Image as ImageIcon, Users as UsersIcon } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle } from '@/components/ui/dialog';
import { Student } from '../SchoolGuardApp';
import { CLASSES, BLOOD_GROUPS } from '@/lib/constants';
import { Language, translations } from '@/lib/translations';

interface StudentFormModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (student: Student) => void;
  editingStudent: Student | null;
  language: Language;
}

export function StudentFormModal({ isOpen, onClose, onSave, editingStudent, language }: StudentFormModalProps) {
  const [photo, setPhoto] = useState<string | null>(null);
  const [isCapturing, setIsCapturing] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  useEffect(() => {
    if (editingStudent) {
      setPhoto(editingStudent.photo || null);
    } else {
      setPhoto(null);
    }
  }, [editingStudent, isOpen]);

  const startCamera = async () => {
    setIsCapturing(true);
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
      if (videoRef.current) videoRef.current.srcObject = stream;
    } catch (err) {
      setIsCapturing(false);
    }
  };

  const capturePhoto = () => {
    const canvas = canvasRef.current;
    const video = videoRef.current;
    if (canvas && video) {
      canvas.width = 400;
      canvas.height = 500;
      canvas.getContext('2d')?.drawImage(video, 0, 0, 400, 500);
      setPhoto(canvas.toDataURL('image/jpeg'));
      stopCamera();
    }
  };

  const stopCamera = () => {
    if (videoRef.current?.srcObject) {
      (videoRef.current.srcObject as MediaStream).getTracks().forEach(t => t.stop());
    }
    setIsCapturing(false);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setPhoto(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  const handleSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const formData = new FormData(e.currentTarget);
    const studentId = editingStudent?.id || `SG-${Math.floor(1000 + Math.random() * 9000)}`;
    
    onSave({
      id: studentId,
      name: formData.get('name') as string,
      class: formData.get('class') as string,
      bloodGroup: formData.get('bloodGroup') as string,
      phoneSms: formData.get('phoneSms') as string,
      phoneWhatsapp: formData.get('phoneWhatsapp') as string,
      photo: photo || undefined,
    });
  };

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl p-0 overflow-hidden border-none rounded-[3.5rem] bg-white shadow-2xl" dir={isRtl ? 'rtl' : 'ltr'}>
        <DialogHeader className={`bg-primary p-10 flex flex-row justify-between items-center text-white ${isRtl ? 'flex-row-reverse' : ''}`}>
          <DialogTitle className={`text-xl font-black uppercase italic tracking-tight ${isRtl ? 'text-right' : ''}`}>
            {editingStudent ? t.modals.edit : t.modals.register}
          </DialogTitle>
          <button type="button" onClick={onClose} className="p-2 hover:bg-white/10 rounded-full transition-colors"><X size={24} /></button>
        </DialogHeader>
        
        <form onSubmit={handleSubmit} className="p-10 space-y-10 max-h-[85vh] overflow-y-auto no-scrollbar">
          <div className={`flex flex-col md:flex-row gap-10 items-start ${isRtl ? 'md:flex-row-reverse' : ''}`}>
            <div className="w-full md:w-44 space-y-4 shrink-0">
              <div className="aspect-[3/4] bg-muted rounded-[2.5rem] border-2 border-dashed border-border overflow-hidden relative flex items-center justify-center group">
                {isCapturing ? (
                  <video ref={videoRef} autoPlay playsInline className="w-full h-full object-cover" />
                ) : photo ? (
                  <img src={photo} className="w-full h-full object-cover" />
                ) : (
                  <UsersIcon size={40} className="text-muted-foreground/20" />
                )}
                
                {isCapturing && (
                  <button type="button" onClick={capturePhoto} className="absolute bottom-5 bg-primary text-white px-5 py-2.5 rounded-full font-black text-[9px] uppercase shadow-xl">
                    {t.modals.capture}
                  </button>
                )}
              </div>
              
              <div className="flex flex-col gap-2">
                <button type="button" onClick={startCamera} className={`w-full bg-muted/50 text-muted-foreground py-3 rounded-2xl text-[9px] font-black uppercase tracking-widest hover:bg-primary/5 hover:text-primary transition-all flex items-center justify-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <Camera size={14} /> {t.modals.photo}
                </button>
                <button type="button" onClick={() => fileInputRef.current?.click()} className={`w-full bg-muted/50 text-muted-foreground py-3 rounded-2xl text-[9px] font-black uppercase tracking-widest hover:bg-primary/5 hover:text-primary transition-all flex items-center justify-center gap-2 ${isRtl ? 'flex-row-reverse' : ''}`}>
                  <ImageIcon size={14} /> {t.modals.gallery}
                </button>
                <input type="file" ref={fileInputRef} onChange={handleFileUpload} accept="image/*" className="hidden" />
              </div>
            </div>

            <div className="flex-1 space-y-6 w-full">
              <FormInput label={t.modals.nameLabel} name="name" defaultValue={editingStudent?.name} required isRtl={isRtl} />
              
              <div className="grid grid-cols-2 gap-5">
                <FormSelect label={t.modals.classLabel} name="class" options={CLASSES} defaultValue={editingStudent?.class} isRtl={isRtl} />
                <FormSelect label={t.modals.bloodLabel} name="bloodGroup" options={BLOOD_GROUPS} defaultValue={editingStudent?.bloodGroup} isRtl={isRtl} />
              </div>

              <div className="grid grid-cols-2 gap-5">
                <FormInput label={t.modals.smsLabel} name="phoneSms" defaultValue={editingStudent?.phoneSms} required placeholder="+224 ..." isRtl={isRtl} />
                <FormInput label={t.modals.whatsappLabel} name="phoneWhatsapp" defaultValue={editingStudent?.phoneWhatsapp} required placeholder="+224 ..." isRtl={isRtl} />
              </div>
            </div>
          </div>

          <div className={`pt-6 border-t border-border flex gap-4 ${isRtl ? 'flex-row-reverse' : ''}`}>
            <button type="button" onClick={onClose} className="flex-1 bg-muted text-muted-foreground py-5 rounded-3xl font-black uppercase text-[10px] tracking-widest hover:bg-muted-foreground/10 transition-all">{t.modals.cancel}</button>
            <button type="submit" className={`flex-[2] bg-primary text-white py-5 rounded-3xl font-black uppercase text-[10px] tracking-widest shadow-2xl shadow-primary/30 hover:bg-primary/90 transition-all flex items-center justify-center gap-3 ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Save size={18} /> {t.modals.save}
            </button>
          </div>
        </form>
        <canvas ref={canvasRef} className="hidden" />
      </DialogContent>
    </Dialog>
  );
}

function FormInput({ label, name, defaultValue, required, placeholder, isRtl }: any) {
  return (
    <div className={`space-y-2 ${isRtl ? 'text-right' : ''}`}>
       <label className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.2em] px-1">{label}</label>
       <input 
        name={name} 
        defaultValue={defaultValue} 
        required={required} 
        placeholder={placeholder}
        dir={isRtl ? 'rtl' : 'ltr'}
        className={`w-full px-6 py-4 bg-muted/30 border-none rounded-2xl focus:ring-2 focus:ring-primary outline-none text-sm font-bold placeholder:text-muted-foreground/30 ${isRtl ? 'text-right' : ''}`} 
       />
    </div>
  );
}

function FormSelect({ label, name, options, defaultValue, isRtl }: any) {
  return (
    <div className={`space-y-2 ${isRtl ? 'text-right' : ''}`}>
      <label className="text-[10px] font-black text-muted-foreground uppercase tracking-[0.2em] px-1">{label}</label>
      <select 
        name={name} 
        defaultValue={defaultValue || options[0]} 
        dir={isRtl ? 'rtl' : 'ltr'}
        className={`w-full px-6 py-4 bg-muted/30 border-none rounded-2xl focus:ring-2 focus:ring-primary outline-none text-sm font-bold appearance-none cursor-pointer ${isRtl ? 'text-right' : ''}`}
      >
        {options.map((opt: string) => <option key={opt} value={opt}>{opt}</option>)}
      </select>
    </div>
  );
}
