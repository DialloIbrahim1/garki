"use client";

import React, { useState } from 'react';
import { UserCheck, UserX, Smartphone, Users as UsersIcon, Printer } from 'lucide-react';
import { Student, Attendance } from '../SchoolGuardApp';
import { personalizeParentCommunication } from '@/ai/flows/personalized-parent-communication';
import { useToast } from '@/hooks/use-toast';
import { Language, translations } from '@/lib/translations';

interface AttendanceTrackingProps {
  students: Student[];
  attendance: Attendance;
  language: Language;
  onMark: (id: string, status: 'present' | 'absent') => void;
}

export function AttendanceTracking({ students, attendance, language, onMark }: AttendanceTrackingProps) {
  const { toast } = useToast();
  const [sending, setSending] = useState<string | null>(null);
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';
  const today = new Date().toLocaleDateString(language === 'fr' ? 'fr-FR' : 'en-US', {
    day: 'numeric',
    month: 'long',
    year: 'numeric'
  });

  const handleNotify = async (student: Student) => {
    const status = attendance[student.id];
    if (!status) return;

    setSending(student.id);
    try {
      const { message } = await personalizeParentCommunication({
        studentName: student.name,
        studentClass: student.class,
        messageType: 'attendance',
        attendancePhrase: status === 'present' ? "est PRÉSENT(E)" : "est ABSENT(E)"
      });

      const encodedMsg = encodeURIComponent(message);
      const phone = student.phoneWhatsapp || student.phoneSms;
      if (!phone) throw new Error("Aucun numéro");
      
      const whatsappUrl = `https://wa.me/${phone.replace(/\s/g, '')}?text=${encodedMsg}`;
      window.open(whatsappUrl, '_blank');
      
      toast({ title: t.attendanceList.parentNotification, description: "WhatsApp ouvert." });
    } catch (err) {
      toast({ variant: "destructive", title: "Erreur" });
    } finally {
      setSending(null);
    }
  };

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="space-y-6" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Header with Print Button */}
      <div className={`flex justify-between items-center no-print ${isRtl ? 'flex-row-reverse' : ''}`}>
        <div className={isRtl ? 'text-right' : ''}>
          <h2 className="text-xl font-black text-foreground uppercase italic tracking-tight">{t.attendance}</h2>
          <p className="text-[10px] font-bold text-muted-foreground uppercase tracking-widest mt-1">{today}</p>
        </div>
        <button 
          onClick={handlePrint}
          className={`flex items-center gap-2 bg-primary hover:bg-primary/90 text-white px-5 py-3 rounded-2xl font-black transition-all shadow-xl shadow-primary/20 active:scale-95 text-[10px] uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}
        >
          <Printer size={16} /> {t.attendanceList.print}
        </button>
      </div>

      {/* Print-only Header */}
      <div className="hidden print:block text-center space-y-4 mb-10 border-b-2 border-primary/20 pb-6">
        <div className="flex items-center justify-center gap-4">
          <div className="w-12 h-12 bg-black rounded-xl flex items-center justify-center text-white italic font-black text-xl rotate-3">G</div>
          <div className="text-left">
            <h1 className="text-xl font-black uppercase tracking-tight leading-none">IB GARKI DIALLO</h1>
            <p className="text-[8px] font-bold text-primary uppercase tracking-[0.3em] mt-1">{t.subtitle}</p>
          </div>
        </div>
        <h2 className="text-2xl font-black uppercase tracking-tighter italic">{t.attendanceList.title}</h2>
        <p className="text-sm font-bold text-muted-foreground uppercase tracking-widest">{today}</p>
      </div>

      <div className="bg-white rounded-[3rem] border border-border shadow-sm overflow-hidden print:border-none print:shadow-none print:rounded-none">
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead className="bg-muted/50 border-b border-border print:bg-slate-50">
              <tr className={isRtl ? 'text-right' : ''}>
                <th className="px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest print:px-4 print:py-4">{t.attendanceList.student}</th>
                <th className="hidden print:table-cell px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest text-center">{t.attendanceList.status}</th>
                <th className="px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest text-center no-print">{t.attendanceList.marking}</th>
                <th className={`px-10 py-6 text-[10px] font-black text-muted-foreground uppercase tracking-widest ${isRtl ? 'text-left' : 'text-right'} no-print`}>{t.attendanceList.parentNotification}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-border">
              {students.length > 0 ? students.map(s => (
                <tr key={s.id} className="hover:bg-muted/30 transition-colors group print:hover:bg-transparent">
                  <td className={`px-10 py-5 print:px-4 print:py-3 ${isRtl ? 'text-right' : ''}`}>
                    <div className={`flex items-center gap-5 ${isRtl ? 'flex-row-reverse' : ''}`}>
                      <div className="w-12 h-12 rounded-[1.25rem] bg-muted overflow-hidden border border-border shadow-sm flex items-center justify-center no-print">
                        {s.photo ? <img src={s.photo} className="w-full h-full object-cover" /> : <UsersIcon size={20} className="text-muted-foreground/30" />}
                      </div>
                      <div>
                        <p className="text-sm font-black text-foreground leading-tight tracking-tight uppercase print:text-xs">{s.name}</p>
                        <p className="text-[10px] font-bold text-primary uppercase mt-0.5 print:text-[8px]">{s.class}</p>
                      </div>
                    </div>
                  </td>
                  <td className="hidden print:table-cell px-10 py-5 text-center print:px-4 print:py-3 border-l border-r border-slate-100">
                    <span className={`text-[9px] font-black uppercase px-3 py-1 rounded-full border ${
                      attendance[s.id] === 'present' 
                        ? 'text-emerald-600 bg-emerald-50 border-emerald-100' 
                        : attendance[s.id] === 'absent' 
                          ? 'text-rose-600 bg-rose-50 border-rose-100' 
                          : 'text-slate-400 bg-slate-50 border-slate-200'
                    }`}>
                      {attendance[s.id] === 'present' ? 'Présent' : attendance[s.id] === 'absent' ? 'Absent' : '---'}
                    </span>
                  </td>
                  <td className="px-10 py-5 no-print">
                    <div className="flex items-center justify-center gap-4">
                      <button 
                        onClick={() => onMark(s.id, 'present')} 
                        className={`p-3.5 rounded-2xl transition-all shadow-sm ${attendance[s.id] === 'present' ? 'bg-emerald-500 text-white shadow-emerald-200' : 'bg-background text-muted-foreground/30 hover:text-emerald-500 hover:bg-emerald-50 border border-transparent'}`}
                      >
                        <UserCheck size={20} />
                      </button>
                      <button 
                        onClick={() => onMark(s.id, 'absent')} 
                        className={`p-3.5 rounded-2xl transition-all shadow-sm ${attendance[s.id] === 'absent' ? 'bg-rose-500 text-white shadow-rose-200' : 'bg-background text-muted-foreground/30 hover:text-rose-500 hover:bg-rose-50 border border-transparent'}`}
                      >
                        <UserX size={20} />
                      </button>
                    </div>
                  </td>
                  <td className="px-10 py-5 no-print">
                    <button 
                      onClick={() => handleNotify(s)} 
                      disabled={!attendance[s.id] || sending === s.id}
                      className={`px-5 py-3 rounded-2xl transition-all flex items-center gap-3 ${isRtl ? 'mr-auto' : 'ml-auto'} text-[10px] font-black uppercase tracking-widest shadow-sm ${attendance[s.id] ? 'bg-primary text-white hover:bg-primary/90' : 'bg-muted text-muted-foreground/30 cursor-not-allowed'}`}
                    >
                      {sending === s.id ? t.attendanceList.generating : (
                        <>
                          <Smartphone size={16} /> WhatsApp
                        </>
                      )}
                    </button>
                  </td>
                </tr>
              )) : (
                <tr>
                  <td colSpan={isRtl ? 4 : 4} className="px-10 py-20 text-center">
                    <p className="text-muted-foreground font-black uppercase text-sm italic">{t.attendanceList.noStudent}</p>
                  </td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Print-only Footer */}
      <div className="hidden print:flex flex-col items-center gap-4 text-center mt-20 opacity-40">
        <p className="text-[10px] font-black uppercase tracking-widest">Document généré le {today} par GARKI IB APP</p>
        <div className="w-full flex justify-between mt-10">
          <div className="text-center border-t border-slate-200 pt-4 w-40">
            <p className="text-[8px] font-black uppercase">Signature Surveillant</p>
          </div>
          <div className="text-center border-t border-slate-200 pt-4 w-40">
            <p className="text-[8px] font-black uppercase">Sceau Direction</p>
          </div>
        </div>
      </div>
    </div>
  );
}