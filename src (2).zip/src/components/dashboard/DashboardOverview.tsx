"use client";

import React, { useState, useEffect } from 'react';
import { Users, UserCheck, Wallet, TrendingUp, Sparkles, AlertCircle, PieChart as PieChartIcon, LogIn, LogOut } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { FRAIS_SCOLARITE_BASE } from '@/lib/constants';
import { dailyOperationalInsights } from '@/ai/flows/daily-operational-insights';
import { Skeleton } from '@/components/ui/skeleton';
import { PieChart, Pie, Cell, ResponsiveContainer, Tooltip as RechartsTooltip, Legend } from 'recharts';
import { formatCurrency } from '@/lib/utils';
import { translations, Language } from '@/lib/translations';

interface DashboardOverviewProps {
  stats: {
    total: number;
    present: number;
    totalPaid: number; // in GNF
    totalDue: number; // in GNF
  };
  students: any[];
  attendance: any;
  payments: any;
  currency: string;
  language: Language;
}

export function DashboardOverview({ stats, students, attendance, payments, currency, language }: DashboardOverviewProps) {
  const [insight, setInsight] = useState<string | null>(null);
  const [loadingInsight, setLoadingInsight] = useState(false);
  const t = translations[language];
  const isRtl = language === 'ar' || language === 'adlam' || language === 'nko';

  useEffect(() => {
    const fetchInsight = async () => {
      if (students.length === 0) return;
      setLoadingInsight(true);
      try {
        const result = await dailyOperationalInsights({
          students: students.map(s => ({ id: s.id, name: s.name, class: s.class })),
          attendance,
          payments,
          FRAIS_SCOLARITE: FRAIS_SCOLARITE_BASE,
          DEVISE: "GNF", 
          todayStr: new Date().toISOString().split('T')[0]
        });
        setInsight(result);
      } catch (err) {
        console.error("AI Insight Error:", err);
      } finally {
        setLoadingInsight(false);
      }
    };

    fetchInsight();
  }, [students.length, attendance, payments, currency]);

  const attendanceData = [
    { name: t.stats.present, value: stats.present, fill: 'hsl(var(--chart-3))' },
    { name: t.stats.absent, value: stats.total - stats.present, fill: 'hsl(var(--chart-4))' },
  ];

  return (
    <div className="space-y-8" dir={isRtl ? 'rtl' : 'ltr'}>
      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard label={t.stats.totalStudents} value={stats.total} icon={<Users />} color="primary" isRtl={isRtl} />
        <StatCard label={t.stats.presentToday} value={stats.present} icon={<UserCheck />} color="emerald" isRtl={isRtl} />
        <StatCard label={t.stats.totalCollected} value={formatCurrency(stats.totalPaid, currency)} icon={<Wallet />} color="amber" isRtl={isRtl} />
        <StatCard label={t.stats.remainingToCollect} value={formatCurrency(stats.totalDue - stats.totalPaid, currency)} icon={<TrendingUp />} color="rose" isRtl={isRtl} />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Chart Section */}
        <Card className="rounded-[2.5rem] border-none shadow-xl shadow-primary/5 bg-white overflow-hidden lg:col-span-1">
          <CardHeader>
            <CardTitle className={`text-sm font-black flex items-center gap-2 text-foreground uppercase tracking-widest ${isRtl ? 'flex-row-reverse' : ''}`}>
              <PieChartIcon className={`h-4 w-4 text-primary ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.stats.attendanceChart}
            </CardTitle>
          </CardHeader>
          <CardContent className="h-[300px]">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={attendanceData}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="value"
                >
                  {attendanceData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.fill} />
                  ))}
                </Pie>
                <RechartsTooltip />
                <Legend verticalAlign="bottom" height={36}/>
              </PieChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* AI Insight Box */}
        <Card className="rounded-[2.5rem] border-none shadow-xl shadow-primary/5 bg-white overflow-hidden lg:col-span-2">
          <CardHeader className="bg-primary/5 pb-2">
            <CardTitle className={`text-sm font-black flex items-center gap-2 text-primary ${isRtl ? 'flex-row-reverse' : ''}`}>
              <Sparkles className={`h-4 w-4 ${isRtl ? 'ml-2' : 'mr-2'}`} /> {t.aiInsight}
            </CardTitle>
          </CardHeader>
          <CardContent className="pt-6">
            {loadingInsight ? (
              <div className="space-y-3">
                <Skeleton className="h-4 w-full" />
                <Skeleton className="h-4 w-[90%]" />
                <Skeleton className="h-4 w-[85%]" />
              </div>
            ) : insight ? (
              <div className={`prose prose-sm max-w-none text-muted-foreground font-medium leading-relaxed whitespace-pre-line ${isRtl ? 'text-right' : ''}`}>
                {insight}
              </div>
            ) : (
              <div className={`flex items-center gap-3 text-muted-foreground italic ${isRtl ? 'flex-row-reverse' : ''}`}>
                <AlertCircle className="h-4 w-4" />
                Capturez des données pour générer des insights.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Quick Access Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 no-print">
        <Card className="rounded-[2.5rem] border-none shadow-sm bg-white overflow-hidden p-8 flex items-center gap-6 group hover:shadow-xl transition-all cursor-default">
          <div className="w-16 h-16 rounded-2xl bg-emerald-50 text-emerald-500 flex items-center justify-center group-hover:scale-110 transition-transform">
            <LogIn size={32} />
          </div>
          <div>
            <h4 className="text-sm font-black uppercase tracking-widest">{language === 'fr' ? 'ENTRÉES RÉCENTES' : 'RECENT ENTRIES'}</h4>
            <p className="text-[10px] font-bold text-muted-foreground uppercase mt-1">Dernière scan: {new Date().toLocaleTimeString()}</p>
          </div>
        </Card>
        <Card className="rounded-[2.5rem] border-none shadow-sm bg-white overflow-hidden p-8 flex items-center gap-6 group hover:shadow-xl transition-all cursor-default">
          <div className="w-16 h-16 rounded-2xl bg-primary/10 text-primary flex items-center justify-center group-hover:scale-110 transition-transform">
            <LogOut size={32} />
          </div>
          <div>
            <h4 className="text-sm font-black uppercase tracking-widest">{language === 'fr' ? 'SORTIES RÉCENTES' : 'RECENT EXITS'}</h4>
            <p className="text-[10px] font-bold text-muted-foreground uppercase mt-1">Système actif</p>
          </div>
        </Card>
      </div>
    </div>
  );
}

function StatCard({ label, value, icon, color, isRtl }: { label: string, value: string | number, icon: React.ReactNode, color: string, isRtl?: boolean }) {
  const colorMap: Record<string, string> = {
    primary: "bg-primary/10 text-primary",
    emerald: "bg-emerald-100 text-emerald-600",
    amber: "bg-amber-100 text-amber-600",
    rose: "bg-rose-100 text-rose-600"
  };

  return (
    <Card className="rounded-[2.5rem] border-none shadow-sm hover:shadow-xl hover:translate-y-[-4px] transition-all duration-300 group">
      <CardContent className={`p-6 flex items-center gap-5 ${isRtl ? 'flex-row-reverse text-right' : ''}`}>
        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center group-hover:scale-110 transition-transform ${colorMap[color]}`}>
          {React.cloneElement(icon as React.ReactElement, { size: 24 })}
        </div>
        <div>
          <p className="text-[10px] font-black text-muted-foreground uppercase tracking-widest">{label}</p>
          <h3 className="text-xl font-black text-foreground leading-none mt-1.5">{value}</h3>
        </div>
      </CardContent>
    </Card>
  );
}
