'use server';
/**
 * @fileOverview A Genkit flow that generates a daily operational summary for school administrators.
 *
 * - dailyOperationalInsights - A function that generates a daily summary of attendance and financial statuses.
 * - DailyOperationalInsightsInput - The input type for the dailyOperationalInsights function.
 * - DailyOperationalInsightsOutput - The return type for the dailyOperationalInsights function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

// Input schema for the Genkit flow
const DailyOperationalInsightsInputSchema = z.object({
  students: z.array(z.object({
    id: z.string().describe('Unique ID of the student'),
    name: z.string().describe('Full name of the student'),
    class: z.string().describe('Class of the student'),
  })).describe('List of all students'),
  attendance: z.record(z.enum(['present', 'absent', 'unknown'])).describe('Record of student attendance for the day, by student ID'),
  payments: z.record(z.object({
    amountPaid: z.number().describe('Total amount paid by the student so far'),
  })).describe('Record of student payment statuses, by student ID'),
  FRAIS_SCOLARITE: z.number().describe('Total school fees for the year'),
  DEVISE: z.string().describe('Currency used for payments'),
  todayStr: z.string().describe('Today\'s date in YYYY-MM-DD format'),
});
export type DailyOperationalInsightsInput = z.infer<typeof DailyOperationalInsightsInputSchema>;

// Output schema for the Genkit flow
const DailyOperationalInsightsOutputSchema = z.string().describe('A concise daily operational summary for the school administrator.');
export type DailyOperationalInsightsOutput = z.infer<typeof DailyOperationalInsightsOutputSchema>;

const dailyOperationalInsightsPrompt = ai.definePrompt({
  name: 'dailyOperationalInsightsPrompt',
  input: {schema: z.object({
    todayStr: z.string(),
    totalStudents: z.number(),
    totalPresent: z.number(),
    totalAbsent: z.number(),
    absentStudents: z.array(z.object({ name: z.string(), class: z.string() })),
    totalPaidAmount: z.number(),
    totalRemainingAmount: z.number(),
    unpaidStudents: z.array(z.object({ name: z.string(), class: z.string(), remaining: z.number() })),
    DEVISE: z.string(),
    FRAIS_SCOLARITE: z.number(),
  })},
  output: {schema: DailyOperationalInsightsOutputSchema},
  prompt: `You are an AI assistant for a school administrator. Your task is to generate a concise daily operational summary based on the provided data for {{todayStr}}.
Focus on key attendance highlights and financial payment statuses, identifying any areas that require immediate attention.

---
Daily Operational Data for {{todayStr}}:

**Attendance Summary:**
- Total Students: {{totalStudents}}
- Students Present: {{totalPresent}}
- Students Absent: {{totalAbsent}}

{{#if absentStudents}}
**Absent Students Today:**
{{#each absentStudents}}
- {{this.name}} (Class: {{this.class}})
{{/each}}
{{else}}
All registered students are present today.
{{/if}}

**Financial Summary:**
- Total School Fees per Student: {{FRAIS_SCOLARITE}} {{DEVISE}}
- Total Amount Paid by All Students: {{totalPaidAmount}} {{DEVISE}}
- Total Remaining Amount to Collect: {{totalRemainingAmount}} {{DEVISE}}

{{#if unpaidStudents}}
**Students with Outstanding Payments:**
{{#each unpaidStudents}}
- {{this.name}} (Class: {{this.class}}): Remaining {{this.remaining}} {{DEVISE}}
{{/each}}
{{else}}
All students have paid their school fees in full.
{{/if}}
---

Based on the data above, provide a summary, highlighting critical information and potential action items for the school administration.
`
});

const dailyOperationalInsightsFlow = ai.defineFlow(
  {
    name: 'dailyOperationalInsightsFlow',
    inputSchema: DailyOperationalInsightsInputSchema,
    outputSchema: DailyOperationalInsightsOutputSchema,
  },
  async (input) => {
    const { students, attendance, payments, FRAIS_SCOLARITE, DEVISE, todayStr } = input;

    const totalStudents = students.length;
    let totalPresent = 0;
    let totalAbsent = 0;
    const absentStudents: { name: string, class: string }[] = [];

    students.forEach(student => {
      if (attendance[student.id] === 'present') {
        totalPresent++;
      } else if (attendance[student.id] === 'absent') {
        totalAbsent++;
        absentStudents.push({ name: student.name, class: student.class });
      }
      // If 'unknown', don't count towards present or absent for now, could be an area for improvement.
    });

    let totalPaidAmount = 0;
    const unpaidStudents: { name: string, class: string, remaining: number }[] = [];

    students.forEach(student => {
      const amountPaid = payments[student.id]?.amountPaid || 0;
      totalPaidAmount += amountPaid;
      const remaining = FRAIS_SCOLARITE - amountPaid;
      if (remaining > 0) {
        unpaidStudents.push({ name: student.name, class: student.class, remaining: remaining });
      }
    });

    const totalRemainingAmount = (totalStudents * FRAIS_SCOLARITE) - totalPaidAmount;

    const { output } = await dailyOperationalInsightsPrompt({
      todayStr,
      totalStudents,
      totalPresent,
      totalAbsent,
      absentStudents,
      totalPaidAmount,
      totalRemainingAmount,
      unpaidStudents,
      DEVISE,
      FRAIS_SCOLARITE,
    });
    return output!;
  }
);

export async function dailyOperationalInsights(input: DailyOperationalInsightsInput): Promise<DailyOperationalInsightsOutput> {
  return dailyOperationalInsightsFlow(input);
}
