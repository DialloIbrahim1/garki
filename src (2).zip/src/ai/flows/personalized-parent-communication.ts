'use server';
/**
 * @fileOverview A Genkit flow for generating personalized WhatsApp messages for parents.
 *
 * - personalizeParentCommunication - A function that generates a personalized message based on input.
 * - PersonalizedParentCommunicationInput - The input type for the personalizeParentCommunication function.
 * - PersonalizedParentCommunicationOutput - The return type for the personalizeParentCommunication function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const PersonalizedParentCommunicationInputSchema = z.object({
  studentName: z.string().describe('The full name of the student.').min(1, 'Student name cannot be empty.'),
  studentClass: z.string().describe('The class of the student.').min(1, 'Student class cannot be empty.'),
  messageType: z.union([
    z.literal('attendance'),
    z.literal('finance'),
    z.literal('entry'),
    z.literal('exit'),
    z.literal('general')
  ]).describe('Type of message to generate: "attendance", "finance", "entry", "exit", or "general".'),
  attendancePhrase: z.string().optional().describe('A phrase describing the student\'s attendance status, e.g., "est PRÉSENT(E)". Required for "attendance" message type.').nullable(),
  remainingAmount: z.string().optional().describe('The formatted remaining balance for tuition, e.g., "150000 GNF". Required for "finance" message type.').nullable(),
  scanTime: z.string().optional().describe('The time of QR code scan, e.g., "10:30 AM". Required for "entry" or "exit" message types.').nullable()
});
export type PersonalizedParentCommunicationInput = z.infer<typeof PersonalizedParentCommunicationInputSchema>;

const PersonalizedParentCommunicationOutputSchema = z.object({
  message: z.string().describe('The personalized WhatsApp message for the parent.').min(1, 'Generated message cannot be empty.'),
});
export type PersonalizedParentCommunicationOutput = z.infer<typeof PersonalizedParentCommunicationOutputSchema>;

const prompt = ai.definePrompt({
  name: 'generatePersonalizedParentMessagePrompt',
  input: {schema: PersonalizedParentCommunicationInputSchema},
  output: {schema: PersonalizedParentCommunicationOutputSchema},
  prompt: `You are an AI assistant tasked with generating personalized WhatsApp messages for parents of students at IB Garki Diallo school.\nGenerate a concise and appropriate message based on the provided student information and message type.\n\n---\nStudent Name: {{{studentName}}}\nStudent Class: {{{studentClass}}}\nMessage Type: {{{messageType}}}\n---\n\n{{#eq messageType "attendance"}}\nBonjour, nous vous informons que votre enfant {{{studentName}}} ({{{studentClass}}}) {{{attendancePhrase}}} à l'école aujourd'hui. Cordialement, Direction IB Garki.\n{{/eq}}\n\n{{#eq messageType "finance"}}\nRAPPEL PAIEMENT : Bonjour, il reste un solde de {{{remainingAmount}}} à régler pour la scolarité de {{{studentName}}}. Merci de régulariser au plus vite. Direction IB Garki.\n{{/eq}}\n\n{{#eq messageType "entry"}}\nALERTE PRÉSENCE : Votre enfant {{{studentName}}} ({{{studentClass}}}) vient de SCANNER sa carte pour l'ENTRÉE à l'école ({{{scanTime}}}). Bonne journée.\n{{/eq}}\n\n{{#eq messageType "exit"}}\nALERTE SORTIE : Votre enfant {{{studentName}}} ({{{studentClass}}}) vient de SCANNER sa carte pour la SORTIE de l'école ({{{scanTime}}}). Direction IB Garki.\n{{/eq}}\n\n{{#eq messageType "general"}}\nBonjour, nous essayons de vous contacter concernant {{{studentName}}}. Merci de nous rappeler.\n{{/eq}}\n\n{{!-- Fallback message if messageType is not recognized or specific data is missing --}}\n{{#unless (or (eq messageType "attendance") (eq messageType "finance") (eq messageType "entry") (eq messageType "exit") (eq messageType "general"))}}\nBonjour, nous essayons de vous contacter concernant {{{studentName}}}. Merci de nous rappeler.\n{{/unless}}`
});

const personalizedParentCommunicationFlow = ai.defineFlow(
  {
    name: 'personalizedParentCommunicationFlow',
    inputSchema: PersonalizedParentCommunicationInputSchema,
    outputSchema: PersonalizedParentCommunicationOutputSchema,
  },
  async (input) => {
    const {output} = await prompt(input);
    if (!output?.message) {
      throw new Error('Failed to generate a personalized message.');
    }
    return output;
  }
);

export async function personalizeParentCommunication(input: PersonalizedParentCommunicationInput): Promise<PersonalizedParentCommunicationOutput> {
  return personalizedParentCommunicationFlow(input);
}
