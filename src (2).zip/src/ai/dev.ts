import { config } from 'dotenv';
config();

import '@/ai/flows/daily-operational-insights.ts';
import '@/ai/flows/personalized-parent-communication.ts';