
"use client";

import React, { useState } from 'react';
import { SchoolGuardApp } from "@/components/SchoolGuardApp";
import { Login } from "@/components/auth/Login";
import { Language } from "@/lib/translations";
import { useUser } from '@/firebase';
import { Skeleton } from '@/components/ui/skeleton';

export default function Home() {
  const [language, setLanguage] = useState<Language>('fr');
  const [guestAccess, setGuestAccess] = useState(false);
  const { user, loading } = useUser();

  // Si l'utilisateur est déjà connecté via Firebase, on saute l'écran de login
  // Sinon on attend de voir si l'accès invité est activé
  if (loading && !guestAccess) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <Skeleton className="w-20 h-20 rounded-2xl" />
      </div>
    );
  }

  // L'utilisateur doit soit être connecté via Firebase, soit avoir cliqué sur "Accès Libre"
  if (!user && !guestAccess) {
    return (
      <main className="min-h-screen bg-background">
        <Login 
          language={language} 
          onLanguageChange={setLanguage} 
          onGuestAccess={() => setGuestAccess(true)}
        />
      </main>
    );
  }

  return (
    <main className="min-h-screen bg-background">
      <SchoolGuardApp 
        initialLanguage={language}
      />
    </main>
  );
}
