import { clsx, type ClassValue } from "clsx"
import { twMerge } from "tailwind-merge"
import { CURRENCIES } from "./constants"

export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs))
}

/**
 * Converts and formats a value from GNF to the target currency
 */
export function formatCurrency(amountGnf: number, targetCurrencyCode: string): string {
  const currency = CURRENCIES.find(c => c.code === targetCurrencyCode) || CURRENCIES[0];
  const convertedAmount = amountGnf * currency.rate;
  
  // Custom formatting for GNF (no decimals)
  if (targetCurrencyCode === 'GNF') {
    return new Intl.NumberFormat('fr-GN', {
      style: 'currency',
      currency: 'GNF',
      maximumFractionDigits: 0,
    }).format(convertedAmount).replace('GNF', 'GNF');
  }

  // General formatting for others
  return new Intl.NumberFormat('fr-FR', {
    style: 'currency',
    currency: targetCurrencyCode,
    minimumFractionDigits: targetCurrencyCode === 'USD' || targetCurrencyCode === 'EUR' ? 2 : 0,
  }).format(convertedAmount);
}
