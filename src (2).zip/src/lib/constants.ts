
export const CLASSES = [
  "6ème A", "6ème B", "5ème A", "5ème B", "4ème A", "4ème B", "3ème A", "3ème B", 
  "Seconde", "Première", "Terminale"
];

export const BLOOD_GROUPS = ["A+", "A-", "B+", "B-", "AB+", "AB-", "O+", "O-", "Inconnu"];

// Base currency is GNF
export const FRAIS_SCOLARITE_BASE = 1500000; 

export const CURRENCIES = [
  { code: "GNF", label: "Franc Guinéen (GNF)", region: "Afrique", rate: 1 },
  { code: "XOF", label: "Franc CFA (XOF)", region: "Afrique", rate: 0.071 },
  { code: "XAF", label: "Franc CFA (XAF)", region: "Afrique", rate: 0.071 },
  { code: "SLE", label: "Leone (SLE)", region: "Afrique", rate: 0.0026 },
  { code: "GMD", label: "Dalasi (GMD)", region: "Afrique", rate: 0.0082 },
  { code: "NGN", label: "Naira Nigérian (NGN)", region: "Afrique", rate: 0.18 },
  { code: "ZAR", label: "Rand Sud-Africain (ZAR)", region: "Afrique", rate: 0.0022 },
  { code: "USD", label: "Dollar US ($)", region: "Amérique", rate: 0.00012 },
  { code: "EUR", label: "Euro (€)", region: "Europe", rate: 0.00011 },
  { code: "GBP", label: "Livre Sterling (£)", region: "Europe", rate: 0.000092 },
  { code: "CAD", label: "Dollar Canadien (CAD)", region: "Amérique", rate: 0.00016 },
];

export const DEVISE_DEFAULT = "GNF";
export const APP_ID = 'app-schoolguard-pro';
