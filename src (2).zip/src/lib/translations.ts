export type Language = 'fr' | 'en' | 'ar' | 'nl' | 'adlam' | 'nko' | 'es' | 'pt' | 'it';

export const translations: Record<Language, any> = {
  fr: {
    title: "GARKI IB APP V1",
    subtitle: "SYSTÈME DE GESTIONAL ÉDUCATIVE",
    dashboard: "DASHBOARD",
    students: "ÉLÈVES",
    attendance: "PRÉSENCES",
    finance: "FINANCES",
    certificates: "CERTIFICATS",
    reports: "BULLETINS",
    scanner: "SCANNER",
    add: "AJOUTER",
    logout: "QUITTER",
    login: {
      title: "ACCÈS SÉCURISÉ",
      subtitle: "Veuillez entrer vos identifiants administrateur",
      placeholder: "Mot de passe...",
      button: "SE CONNECTER",
      error: "Erreur de connexion",
      errorDetails: "Identifiants invalides ou compte non configuré dans Firebase."
    },
    stats: {
      totalStudents: "Total Élèves",
      presentToday: "Présents Aujourd'hui",
      totalCollected: "Total Encaissé",
      remainingToCollect: "Reste à Percevoir",
      attendanceChart: "RÉPARTITION PRÉSENCES",
      present: "Présents",
      absent: "Absents"
    },
    aiInsight: "ANALYSE OPÉRATIONNELLE IA",
    studentList: {
      searchPlaceholder: "Rechercher un nom ou un ID...",
      allClasses: "Toutes",
      noStudent: "Aucun élève trouvé",
      addFirst: "Commencez par ajouter un nouvel élève.",
      idCard: "CARTE",
      pay: "PAYER",
      paid: "OK"
    },
    attendanceList: {
      title: "LISTE D'ÉMARGEMENT DU JOUR",
      student: "Élève",
      marking: "Pointage",
      status: "Statut",
      parentNotification: "Notification Parent",
      noStudent: "Aucun élève dans la base",
      generating: "Génération...",
      print: "IMPRIMER LA LISTE"
    },
    financeList: {
      config: "Configuration Devise",
      autoConversion: "CONVERSION AUTOMATIQUE ACTIVE",
      paidTuition: "Scolarité Payée",
      remainingBalance: "Solde Restant",
      actions: "Actions",
      remind: "Relance",
      collect: "ENCAISSER",
      history: "DERNIÈRES TRANSACTIONS",
      noTransaction: "Aucune transaction",
      receipt: "REÇU DE PAIEMENT",
      printReceipt: "IMPRIMER LE REÇU",
      transactionId: "ID TRANSACTION",
      paymentDate: "DATE DE PAIEMENT",
      amountReceived: "MONTANT REÇU",
      sendWhatsApp: "Envoyer WhatsApp",
      sendSMS: "Envoyer SMS"
    },
    certList: {
      title: "GÉNÉRATEUR DE CERTIFICATS",
      subtitle: "CRÉATION DE DOCUMENTS OFFICIELS",
      searchPlaceholder: "Rechercher un élève...",
      typeLabel: "Type de Certificat",
      types: {
        attendance: "Certificat de Scolarité",
        excellence: "Certificat d'Excellence",
        conduct: "Certificat de Bonne Conduite"
      },
      generate: "GÉNÉRER",
      print: "IMPRIMER LE CERTIFICAT",
      preview: "PRÉVISUALISATION",
      noSelection: "Sélectionnez un élève pour générer un document."
    },
    reportList: {
      title: "GESTION DES BULLETINS",
      subtitle: "RELEVÉS DE NOTES ET ÉVALUATIONS",
      subjects: {
        math: "Mathématiques",
        french: "Français",
        physics: "Physique-Chimie",
        biology: "SVT",
        history: "Histoire-Géo",
        english: "Anglais",
        philosophy: "Philosophie",
        sport: "EPS"
      },
      average: "Moyenne Générale",
      generate: "GÉNÉRER BULLETIN",
      print: "IMPRIMER LE BULLETIN",
      grade: "Note",
      noGrades: "Veuillez saisir les notes de l'élève."
    },
    modals: {
      register: "INSCRIRE UN ÉLÈVE",
      edit: "MODIFIER l'ÉLÈVE",
      nameLabel: "Nom Complet de l'élève",
      classLabel: "Classe",
      bloodLabel: "Groupe Sanguin",
      smsLabel: "Téléphone SMS",
      whatsappLabel: "WhatsApp Parent",
      cancel: "ANNULER",
      save: "ENREGISTRER LE PROFIL",
      capture: "CAPTURER",
      photo: "PHOTO",
      gallery: "GALERIE",
      paymentTitle: "ENREGISTRER UN PAIEMENT",
      confirm: "CONFIRMER",
      scanTitle: "POINTAGE SCAN QR",
      scanSubtitle: "ENTRÉE / SORTIE RAPIDE",
      simulation: "Mode Simulation de Badge",
      finish: "TERMINER LA SESSION",
      startScan: "COMMENCER LE SCAN"
    },
    footer: {
      createdBy: "Cette application a été créée par Ibrahima Garki Diallo.",
      phone: "Téléphone : +32 466 05 37 45",
      email: "Email : garkidi3@gmail.com"
    }
  },
  en: {
    title: "GARKI IB APP V1",
    subtitle: "EDUCATIONAL MANAGEMENT SYSTEM",
    dashboard: "DASHBOARD",
    students: "STUDENTS",
    attendance: "ATTENDANCE",
    finance: "FINANCE",
    certificates: "CERTIFICATES",
    reports: "REPORTS",
    scanner: "SCANNER",
    add: "ADD",
    logout: "LOGOUT",
    login: {
      title: "SECURE ACCESS",
      subtitle: "Please enter your admin credentials",
      placeholder: "Password...",
      button: "LOGIN",
      error: "Login Error",
      errorDetails: "Invalid credentials or account not configured in Firebase."
    },
    stats: {
      totalStudents: "Total Students",
      presentToday: "Present Today",
      totalCollected: "Total Collected",
      remainingToCollect: "Remaining to Collect",
      attendanceChart: "ATTENDANCE DISTRIBUTION",
      present: "Present",
      absent: "Absent"
    },
    aiInsight: "AI OPERATIONAL ANALYSIS",
    studentList: {
      searchPlaceholder: "Search name or ID...",
      allClasses: "All",
      noStudent: "No students found",
      addFirst: "Start by adding a new student.",
      idCard: "CARD",
      pay: "PAY",
      paid: "OK"
    },
    attendanceList: {
      title: "DAILY ATTENDANCE LIST",
      student: "Student",
      marking: "Check-in",
      status: "Status",
      parentNotification: "Parent Notification",
      noStudent: "No students in database",
      generating: "Generating...",
      print: "PRINT LIST"
    },
    financeList: {
      config: "Currency Config",
      autoConversion: "AUTO-CONVERSION ACTIVE",
      paidTuition: "Paid Tuition",
      remainingBalance: "Remaining Balance",
      actions: "Actions",
      remind: "Remind",
      collect: "COLLECT",
      history: "LATEST TRANSACTIONS",
      noTransaction: "No transactions",
      receipt: "PAYMENT RECEIPT",
      printReceipt: "PRINT RECEIPT",
      transactionId: "TRANSACTION ID",
      paymentDate: "PAYMENT DATE",
      amountReceived: "AMOUNT RECEIVED",
      sendWhatsApp: "Send WhatsApp",
      sendSMS: "Send SMS"
    },
    certList: {
      title: "CERTIFICATE GENERATOR",
      subtitle: "OFFICIAL DOCUMENT CREATION",
      searchPlaceholder: "Search for a student...",
      typeLabel: "Certificate Type",
      types: {
        attendance: "Certificate of Attendance",
        excellence: "Certificate of Excellence",
        conduct: "Certificate of Good Conduct"
      },
      generate: "GENERATE",
      print: "PRINT CERTIFICATE",
      preview: "PREVIEW",
      noSelection: "Select a student to generate a document."
    },
    reportList: {
      title: "REPORT CARD MANAGEMENT",
      subtitle: "GRADES AND EVALUATIONS",
      subjects: {
        math: "Mathematics",
        french: "French",
        physics: "Physics-Chemistry",
        biology: "Biology",
        history: "History-Geography",
        english: "English",
        philosophy: "Philosophy",
        sport: "Physical Ed."
      },
      average: "GPA / Average",
      generate: "GENERATE REPORT",
      print: "PRINT REPORT CARD",
      grade: "Grade",
      noGrades: "Please enter student grades."
    },
    modals: {
      register: "REGISTER STUDENT",
      edit: "EDIT STUDENT",
      nameLabel: "Student Full Name",
      classLabel: "Class",
      bloodLabel: "Blood Group",
      smsLabel: "SMS Phone",
      whatsappLabel: "Parent WhatsApp",
      cancel: "CANCEL",
      save: "SAVE PROFILE",
      capture: "CAPTURE",
      photo: "PHOTO",
      gallery: "GALLERY",
      paymentTitle: "RECORD PAYMENT",
      confirm: "CONFIRM",
      scanTitle: "QR SCAN CHECK-IN",
      scanSubtitle: "QUICK ENTRY / EXIT",
      simulation: "Badge Simulation Mode",
      finish: "FINISH SESSION",
      startScan: "START SCAN"
    },
    footer: {
      createdBy: "This application was created by Ibrahima Garki Diallo.",
      phone: "Phone: +32 466 05 37 45",
      email: "Email: garkidi3@gmail.com"
    }
  },
  // ... other languages omitted for brevity but they should be updated similarly
  es: { title: "GARKI IB APP V1", subtitle: "SISTEMA DE GESTIÓN EDUCATIVA", login: { title: "ACCESO SEGURO", subtitle: "Ingrese sus credenciales de administrador", error: "Error de inicio de sesión", errorDetails: "Credenciales inválidas o cuenta no configurada." }, /* ... */ },
  pt: { title: "GARKI IB APP V1", subtitle: "SISTEMA DE GESTÃO EDUCACIONAL", login: { title: "ACESSO SEGURO", subtitle: "Insira suas credenciais de administrador", error: "Erro de login", errorDetails: "Credenciais inválidas ou conta não configurada." }, /* ... */ },
  it: { title: "GARKI IB APP V1", subtitle: "SISTEMA DI GESTIONE EDUCATIVA", login: { title: "ACCESSO SICURO", subtitle: "Inserisci le tue credenziali di amministratore", error: "Errore di accesso", errorDetails: "Credenziali non valide o account non configurato." }, /* ... */ },
  ar: { title: "جاركي IB APP V1", subtitle: "نظام الإدارة التعليمية", login: { title: "دخول آمن", subtitle: "يرجى إدخال بيانات اعتماد المسؤول", error: "خطأ في تسجيل الدخول", errorDetails: "بيانات اعتماد غير صالحة أو لم يتم تكوين الحساب." }, /* ... */ },
  nl: { title: "GARKI IB APP V1", subtitle: "ONDERWIJSBEHEERSYSTEEM", login: { title: "BEVEILIGDE TOEGANG", subtitle: "Voer uw beheerdersgegevens in", error: "Inlogfout", errorDetails: "Ongeldige gegevens of account niet geconfigureerd." }, /* ... */ },
  adlam: { title: "𞤘𞤀𞤑𞤋 𞤋𞤄 𞤀𞤆𞤆 𞤜𞥑", subtitle: "𞤊𞤉𞥅𞤈𞤉 𞤔𞤀𞤐𞤘𞤋𞤈𞤄𞤉", login: { title: "𞤐𞤀𞥄𞤚𞤓𞤘𞤌𞤂 𞤅𞤉𞤋𞤋", subtitle: "𞤏𞤋𞤐𞤁𞤓 𞤆𞤀𞤅𞤏𞤌𞤈𞤁 𞤁𞤓𞤁𞤀𞤂", error: "𞤊𞤌𞤊", errorDetails: "𞤆𞤢𞤧𞤱𞤮𞤪𞤣 𞤮𞥅 𞤸𞤢𞥄𞤲𞤢𞥄" }, /* ... */ },
  nko: { title: "ߜߊߙߑߞߌ ߌߓ ߊߔ ߁", subtitle: "ߞߊ߬ߙߊ߲ ߠߊ߬ߓߊ߰ߙߊ߬ߟߌ ߞߊ߲ߞߋ", login: { title: "ߘߊ߲߬ߠߌ߲߬ ߛߌ߲߬ߓߌ߬ߣߍ߲", subtitle: "ߞߊ߬ߙߊ߲߬ߘߊ ߟߊ߬ ߞߏ߲߬ߘߏ ߛߓߍ߫", error: "ߝߏߝ", errorDetails: "ߞߏ߲߬ߘߏ ߕߍ߫ ߓߍ߲߬" }, /* ... */ }
};
