
export const firebaseConfig = {
  apiKey: "API_KEY_PLACEHOLDER",
  authDomain: "garki.web.app",
  projectId: "garki",
  storageBucket: "garki.firebasestorage.app",
  messagingSenderId: "SENDER_ID_PLACEHOLDER",
  appId: "APP_ID_PLACEHOLDER"
};
